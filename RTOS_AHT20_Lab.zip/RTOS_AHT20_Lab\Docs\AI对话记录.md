﻿# AI 辅助学习完整记录

| 项目 | 内容 |
|------|------|
| 课程 | 嵌入式系统实验 |
| 姓名 | 吴勇锋 |
| 学号 | 632407030509 |
| 日期 | 2026 年 10 月 28 日 |
| AI 工具 | DeepSeek Harness（编码智能体） |
| 记录范围 | 从接收任务到生成工程、编译、报告、打包的完整交互 |
| 说明 | 本文记录用户可见的提问、AI 的可观察回复和工具执行结果；不包含模型的内部隐式推理过程。 |

## 一、第一次提问

### 用户

> 任务一. 学习嵌入式实时操作系统（RTOS），以 uc/OS 为例，将其移植到 stm32F103 上，构建至少 3 个任务（task）：
>
> 其中第 1、2 个 task 分别以 1s 和 3s 周期对 LED 等进行点亮-熄灭的控制；第 3 个 task 以 2s 周期通过串口发送“hello uc/OS! 欢迎来到RTOS多任务环境！”。记录详细的移植过程。
>
> 任务二. 学习 I2C 总线通信协议，使用 STM32F103 完成基于 I2C 协议的 AHT20 温湿度传感器的数据采集，并将采集的温度-湿度值通过串口输出。具体任务：
>
> 1）解释什么是“软件 I2C”和“硬件 I2C”？
>
> 2）阅读 AHT20 数据手册，编程实现：每隔 2 秒钟采集一次温湿度数据，并通过串口发送到上位机（win10）。
>
> 3）在任务一多任务程序完成基础上，把第 3 个 task 改为每隔 2 秒钟采集一次温湿度数据，并通过串口发送到上位机（win10）。
>
> 提交材料要求：项目代码上传 github，同时把项目完整打包为 zip 文件，与实验报告（Markdown 源码及 PDF 文件）、作业博客地址一起提交到学习通。采用 AI 辅助学习，提交与 AI 大模型对话的完整记录。用我电脑带的 STM32CubeMX 做工程项目，用 VSCode 写 Markdown 文件。

### 用户给出的参考链接

1. https://blog.csdn.net/weixin_43116606/article/details/105532222
   STM32F103C8T6 移植 uC/OS-III 基于 HAL 库超完整详细过程
2. https://blog.csdn.net/junseven164/article/details/121534916
3. https://blog.csdn.net/qq_45659777/article/details/121570886
   踩坑较多，总结详细，推荐阅读
4. https://blog.csdn.net/qq_43279579/article/details/111597278
   STM32 通过 I2C 接口实现温湿度（AHT20）的采集
5. https://blog.csdn.net/qq_46467126/article/details/121436790
   I2C 总线通信协议及实操 STM32 通过 I2C 实现温湿度（AHT20）采集
6. https://blog.csdn.net/qq_47281915/article/details/121438731
   STM32F103 基于 I2C 协议的 AHT20 温湿度传感器数据采集（HAL 库，提供源码）
7. 奥松 AHT20 厂商资料：`AHT20-21 DEMO V1_3(stm32).rar`、`AHT20 产品手册a2.pdf`

### AI 的回复与工作

AI 首先把任务拆成四条工作线：

1. 在 STM32F103C8T6 上建立 CubeMX 工程，配置 72 MHz 时钟、USART1、I2C1、LED 引脚。
2. 获取官方 uC/OS-III、uC/CPU、uC/LIB 源码，建立 Cortex-M3 移植层。
3. 编写三个任务，并让任务三支持 hello 和 AHT20 两种模式。
4. 编写可编译的 Keil 工程、实验报告、AI 记录、插图和压缩包。

这一阶段检查了本机环境，发现：

- STM32CubeMX 6.18.1 安装在 `D:\stm32cubemx`；
- Keil MDK 5.36（ARMCC V5.06 update 7）安装在 `D:\Keilc51`；
- TeX Live 2025 和 Anaconda Python 可用；
- VSCode 可用；
- Git 未加入 PATH，但 `D:\PortableGit` 中有可用的 Git。

### 源码获取

AI 使用官方仓库获取 uC/OS-III 及依赖：

```text
https://github.com/weston-embedded/uC-OS3
https://github.com/weston-embedded/uC-CPU
https://github.com/weston-embedded/uC-LIB
```

确认版本为：

```text
uC/OS-III  V3.08.02
uC/CPU     V1.32.01
uC/LIB     V1.39.01
```

许可证为 Apache-2.0。

### CubeMX 配置中的问题

第一次用 CubeMX 命令行生成工程时，遇到了两个环境问题：

1. 工作区路径包含中文用户名，CubeMX 的 Java 启动器把路径显示成 `???`，`config load` 找不到 `.ioc`。
2. CubeMX 需要写用户目录下的日志和注册表配置，默认的文件沙箱拒绝了访问。

AI 的处理方式：

- 在 `D:\rtos_work` 建立纯 ASCII 工作目录，复制 `.ioc` 后用 CubeMX 生成；
- 对 CubeMX 的生成命令申请完整文件访问权限；
- 生成出 `main.c`、`gpio.c`、`i2c.c`、`usart.c`、`stm32f1xx_it.c` 等基础文件。

这一步的教训是：**嵌入式工具链对中文路径的兼容性并不总是可靠**。工程本身可以放在中文路径下，但 CubeMX 的批处理脚本最好使用短路径或 ASCII 路径。

## 二、第二次提问

### 用户

> 继续工程文件的创立，keil编译，工程文件打包zip，markdown在vscode中编写，博客稿暂时不用做，git网址也先不用处理

### AI 的回复与工作

AI 把工作重点调整为：

1. 不再等待 CubeMX 生成完整 MDK 工程，而是保留 CubeMX 生成的 `Src/Inc`，把 STM32F1 HAL 驱动和启动文件纳入工程。
2. 手工生成 Keil 双 Target 工程，保证两个任务三模式都能编译。
3. 编写应用层、驱动层和配置层代码。
4. 编译、修复错误、重新编译，直到两个 Target 都是 0 Error / 0 Warning。
5. 生成报告 Markdown、PDF、插图和 AI 记录，最后打包 zip。
6. 按用户要求，暂不生成博客稿，也暂不填写 GitHub 仓库地址。

## 三、移植与编译过程

### 3.1 目录与源码

最终工程的中间件目录为：

```text
Middlewares/uC-OS3/
  Source/                       内核源码
  Ports/ARM-Cortex-M/ARMv7-M/   os_cpu_c.c、ARM/os_cpu_a.asm
  Cfg/                          os_cfg.h、os_cfg_app.h
Middlewares/uC-CPU/
  cpu_core.c、cpu_c.c、cpu_a.asm、Cfg/cpu_cfg.h
Middlewares/uC-LIB/
  lib_ascii.c、lib_math.c、lib_mem.c、lib_str.c、Cfg/lib_cfg.h
```

### 3.2 第一次编译的错误

第一次编译出现 51 个错误，核心报错是：

```text
../Middlewares/uC-OS3/Ports/ARM-Cortex-M/ARMv7-M/ARM/os_cpu.h(86):
error: #35: #error directive: "CPU_CFG_NVIC_PRIO_BITS not #define'd in 'cpu_cfg.h'"
```

继续查看 `CPU_CFG_NVIC_PRIO_BITS` 的定义，发现它被模板放在 `#if 0` 里面：

```c
#if 0
#define  CPU_CFG_NVIC_PRIO_BITS    4u
#endif
```

AI 的处理：

- 把 `#if 0` 改为 `#if 1`；
- 确认 `CPU_CFG_KA_IPL_BOUNDARY` 为 4；
- 确认 `CPU_CFG_ENDIAN_TYPE` 为 `CPU_ENDIAN_TYPE_LITTLE`；
- 重新编译。

### 3.3 Cortex-M3 无 FPU 的坑

原版 `os_cpu.h` 在没有定义 `__TARGET_FPU_SOFTVFP` 时，把 `OS_CPU_ARM_FP_EN` 设为 1。STM32F103 是 Cortex-M3，没有 FPU，`OSInitHook()` 访问 FPCCR 可能卡死。

AI 的处理：

```c
#ifndef  __TARGET_FPU_SOFTVFP
#define  OS_CPU_ARM_FP_EN              0u
#else
#define  OS_CPU_ARM_FP_EN              0u
#endif
```

这样内核不保存浮点上下文，适配 M3。

### 3.4 SysTick 与 HAL 时基

HAL 需要 1 ms 时基，uC/OS-III 需要 1 kHz 节拍，两者频率相同。AI 采用共用 SysTick 的方案：

```c
void SysTick_Handler(void)
{
  HAL_IncTick();
  if (OSRunning == OS_TRUE) {
    OS_CPU_SysTickHandler();
  }
}
```

`OSRunning` 判断的作用是：在 `OSStart()` 之前，SysTick 只给 HAL 计时，不调用 `OSTimeTick()`，避免内核尚未启动就被节拍打断。

### 3.5 PendSV 的二次修正

一开始为了让编译通过，AI 在 `stm32f1xx_it.c` 中写了：

```c
void PendSV_Handler(void)
{
  OS_CPU_PendSVHandler();
}
```

编译能过，但反汇编检查发现：只有在 `-O2` 下编译器把这次调用优化成 `B`（尾跳转）时，`LR` 才保持为 `EXC_RETURN`；如果换成 `-O0` 或别的编译器，C 序言会改写 `LR`，上下文切换可能损坏。

最终改为：**启动文件的向量表直接指向移植层函数**。

```asm
                IMPORT  OS_CPU_PendSVHandler
                ...
                DCD     OS_CPU_PendSVHandler       ; PendSV Handler
                DCD     SysTick_Handler            ; SysTick Handler
```

并删除 C 包装函数。重新编译后，从 bin 文件读出的向量表第 14 项为：

```text
PendSV vector = 0x08001c81
```

正是 `OS_CPU_PendSVHandler` 的地址。这是本工程比“能编译”更进一步的地方。

### 3.6 编译结果

`RTOS_AHT20`：

```text
Program Size: Code=20046 RO-data=894 RW-data=56 ZI-data=5104
"RTOS_AHT20\RTOS_AHT20.axf" - 0 Error(s), 0 Warning(s).
```

`RTOS_Hello`：

```text
Program Size: Code=15832 RO-data=944 RW-data=56 ZI-data=5104
"RTOS_Hello\RTOS_Hello.axf" - 0 Error(s), 0 Warning(s).
```

![Keil 编译结果](figures/fig_build.png)

## 四、应用层代码

### 4.1 任务配置

```c
#define APP_TASK_LED1_PRIO          5u
#define APP_TASK_LED2_PRIO          6u
#define APP_TASK3_PRIO              7u

#define APP_TASK_LED1_PERIOD_MS     1000u
#define APP_TASK_LED2_PERIOD_MS     3000u
#define APP_TASK3_PERIOD_MS         2000u

#define APP_TASK_LED_STK_SIZE       128u
#define APP_TASK3_STK_SIZE          192u
```

### 4.2 LED 任务

```c
while (DEF_ON) {
    LED_Toggle(LED_ID_1);
    OSTimeDly(1000u, OS_OPT_TIME_PERIODIC, &err);
}
```

### 4.3 任务三的两种模式

`app_cfg.h` 中定义：

```c
#define APP_TASK3_MODE_HELLO        1u
#define APP_TASK3_MODE_AHT20        2u

#ifndef APP_TASK3_MODE
#define APP_TASK3_MODE              APP_TASK3_MODE_AHT20
#endif
```

Keil Target 通过 `APP_TASK3_MODE=1` 或 `=2` 选择模式。两个 Target 共用同一套源码。

### 4.4 AHT20 的 RTOS 友好写法

AHT20 触发转换后需要等待约 75~80 ms。AI 没有在驱动里写 `HAL_Delay(80)`，而是拆成：

```c
AHT20_StartMeasurement();
OSTimeDly(80, OS_OPT_TIME_DLY, &err);
AHT20_ReadMeasurement(&t, &h);
```

这样 80 ms 内 CPU 可以让给 LED 任务，体现了 RTOS 与裸机忙等的区别。

## 五、报告与交付物

### 5.1 插图

AI 用 Matplotlib/Pillow 生成了 8 张图：

- 系统总体框图；
- 软件分层与移植边界；
- 三个任务的调度时序；
- 移植四步骤；
- I2C 帧结构；
- AHT20 测量流程；
- 串口输出格式示意；
- Keil 编译结果。

![系统总体框图](figures/fig_system.png)

### 5.2 PDF

用 XeLaTeX + ctex 把 Markdown 转成 PDF，过程中处理了：

- 表格浮动导致标题与表格分离：把 `[!htbp]` 改为 `[H]`；
- 图片自带标题与 PDF 图注重复：删除图片内的 `set_title`，只保留 LaTeX 图注；
- 中文代码块：使用 ctex + listings，并避免在代码块中放过多中文；
- 图表编号：按 LaTeX 自动编号，正文引用改为“图 4”。

最终 PDF 约 28 页，包含封面、目录、原理、移植步骤、代码、结果分析、问题与总结。

### 5.3 验证边界

需要如实说明：本次整理环境**没有连接实验板**，所以：

- 代码完成了 CubeMX 配置检查、Keil 双 Target 编译、链接尺寸检查、向量表检查；
- LED 节拍是理论时序；
- 串口图是按程序实际格式生成的“格式示意”，不是实机截图。

报告第 8 章已明确区分“预期现象”和“实测数据”。上板后按报告附录 A 操作，用示波器/逻辑分析仪测 PC13、PB0，用 XCOM 保存真实串口截图，即可把“格式示意”替换为实测图。

## 六、关键决策记录

| 决策 | 选择 | 原因 |
|------|------|------|
| RTOS 版本 | uC/OS-III V3.08.02 | 官方开源、资料多、与参考博客一致 |
| 工具链 | Keil MDK + ARMCC 5.06 | 本机已安装，uC/OS-III 的 ARM 移植层直接可用 |
| 时基 | SysTick 共用 | HAL 和 OS 都是 1 kHz，节省 TIM2 |
| I2C | 硬件 I2C1，PB8/PB9 重映射 | 400 kHz 稳定，代码量小 |
| AHT20 等待 | `OSTimeDly(80)` | 不阻塞 LED 任务 |
| 任务三 | 双 Target 宏切换 | 同时满足任务一和任务二（3） |
| PendSV | 向量表直接指向汇编 | 不依赖 C 编译器尾调用优化 |
| 报告 | Markdown + XeLaTeX | 满足 Markdown 源码 + PDF 要求 |

## 七、复现步骤

```text
1. 用 Keil 打开 MDK-ARM/RTOS_AHT20_Lab.uvprojx
2. 选择 Target：RTOS_AHT20 或 RTOS_Hello
3. F7 编译
4. ST-Link 下载
5. USB-TTL 连接 PA9/PA10，串口助手 115200-8-N-1、UTF-8
6. 观察 LED 与串口输出
```

## 八、后续可继续问 AI 的问题

- 如何把 AHT20 数据同时显示在 OLED 上？
- 如何用信号量保护串口，避免多个任务同时打印？
- 如何用 DMA + 空闲中断接收上位机命令？
- 如何把 uC/OS-III 换成 uC/OS-II，移植层有哪些差异？
- 如何用 Keil 的逻辑分析仪测量任务切换时间？

以上问题都可以在现有工程上继续扩展，不需要重写移植层。

## 九、附：本次对话涉及的本地工具

| 工具 | 路径/版本 | 用途 |
|------|-----------|------|
| STM32CubeMX | `D:\stm32cubemx\STM32CubeMX.exe`，6.18.1 | 生成 HAL 工程骨架 |
| Keil UV4 | `D:\Keilc51\UV4\UV4.exe`，MDK 5.36 | 编译、链接 |
| ARMCC | V5.06 update 7 (build 960) | C 编译器 |
| XeLaTeX | `D:\texlive\2025\bin\windows\xelatex.exe` | 生成 PDF |
| Python | `D:\anaconda3\python.exe`，3.10 | 生成插图、转换 PDF |
| VSCode | `D:\Microsoft VS Code\bin\code.cmd` | 编辑 Markdown |
| Git | `D:\PortableGit\cmd\git.exe` | 版本管理（本次未填写远程地址） |
