/**
  ******************************************************************************
  * @file    app_cfg.h
  * @brief   应用层配置：任务优先级、周期、栈大小与任务三工作模式
  *
  *  工程提供两个 Keil Target：
  *    RTOS_Hello  : APP_TASK3_MODE = 1，任务三每 2 s 发送 hello 字符串
  *    RTOS_AHT20  : APP_TASK3_MODE = 2，任务三每 2 s 采集并上报 AHT20
  *
  *  默认值 2，直接编译 RTOS_AHT20 即可完成“任务二（3）”。
  ******************************************************************************
  */
#ifndef __APP_CFG_H
#define __APP_CFG_H

#ifdef __cplusplus
extern "C" {
#endif

/* 任务三工作模式 ------------------------------------------------------------*/
#define APP_TASK3_MODE_HELLO        1u
#define APP_TASK3_MODE_AHT20        2u

#ifndef APP_TASK3_MODE
#define APP_TASK3_MODE              APP_TASK3_MODE_AHT20
#endif

/* 任务优先级：数值越小优先级越高，必须小于 OS_CFG_PRIO_MAX(32) --------------*/
#define APP_TASK_LED1_PRIO          5u
#define APP_TASK_LED2_PRIO          6u
#define APP_TASK3_PRIO              7u

/* 任务周期（ms） ------------------------------------------------------------*/
#define APP_TASK_LED1_PERIOD_MS     1000u
#define APP_TASK_LED2_PERIOD_MS     3000u
#define APP_TASK3_PERIOD_MS         2000u

/* AHT20 一次转换的等待时间（ms），数据手册典型值 75 ms --------------------*/
#define APP_AHT20_CONV_MS           80u

/* 任务栈：单位是 CPU_STK（STM32 上为 4 字节），128 表示 512 字节 ------------*/
#define APP_TASK_LED_STK_SIZE       128u
#define APP_TASK3_STK_SIZE          192u

/* 栈水位警戒线：从栈底算起的保留比例，10 表示保留 10% ---------------------*/
#define APP_TASK_STK_LIMIT_PCT      10u

#ifdef __cplusplus
}
#endif

#endif /* __APP_CFG_H */
