﻿# -*- coding: utf-8 -*-
"""Generate all report figures for the uC/OS-III + AHT20 lab."""
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle, Circle
from PIL import Image, ImageDraw, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIG = os.path.join(ROOT, "figures")
os.makedirs(FIG, exist_ok=True)

plt.rcParams["font.family"] = ["Microsoft YaHei", "SimHei"]
plt.rcParams["axes.unicode_minus"] = False

BLUE = "#2f6fb3"
LBLUE = "#eaf2fb"
GREEN = "#2f8f5b"
LGREEN = "#e9f6ef"
ORANGE = "#d9822b"
LORANGE = "#fdf1e5"
GRAY = "#5a6570"
LGRAY = "#f2f4f6"
RED = "#b83b3b"


def box(ax, x, y, w, h, text, fc=LBLUE, ec=BLUE, fs=12, bold=False, radius=0.08):
    p = FancyBboxPatch((x, y), w, h, boxstyle=f"round,pad=0.02,rounding_size={radius}",
                       linewidth=1.4, edgecolor=ec, facecolor=fc)
    ax.add_patch(p)
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center",
            fontsize=fs, color="#1f2933", fontweight="bold" if bold else "normal",
            linespacing=1.45)
    return p


def arrow(ax, p1, p2, color=GRAY, lw=1.8, style="-|>", ls="-"):
    ax.add_patch(FancyArrowPatch(p1, p2, arrowstyle=style, mutation_scale=14,
                                 linewidth=lw, color=color, linestyle=ls,
                                 shrinkA=2, shrinkB=2))


def save(fig, name):
    fig.savefig(os.path.join(FIG, name), dpi=220, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("saved", name)


def fig_system():
    fig, ax = plt.subplots(figsize=(11.2, 6.2))
    ax.set_xlim(0, 12); ax.set_ylim(0, 7); ax.axis("off")

    box(ax, 4.2, 2.35, 3.6, 2.5,
        "STM32F103C8T6\nCortex-M3 @ 72 MHz\n64 KB Flash / 20 KB RAM",
        fc="#e8f1fb", ec=BLUE, fs=14, bold=True)
    ax.text(6.0, 2.08, "uC/OS-III  +  HAL", ha="center", va="center",
            fontsize=11, color=BLUE)

    box(ax, 0.35, 4.75, 2.5, 1.05, "LED1\nPC13（板载，低电平亮）", fc=LGREEN, ec=GREEN, fs=10)
    box(ax, 0.35, 3.25, 2.5, 1.05, "LED2\nPB0（外接，低电平亮）", fc=LGREEN, ec=GREEN, fs=10)
    arrow(ax, (2.85, 5.27), (4.15, 4.45), GREEN)
    arrow(ax, (2.85, 3.77), (4.15, 3.75), GREEN)
    ax.text(3.45, 4.70, "GPIO 输出", fontsize=9, color=GREEN)

    box(ax, 9.15, 3.45, 2.45, 1.45, "AHT20 温湿度传感器\nI2C 7 位地址 0x38\n3.3 V 供电", fc=LORANGE, ec=ORANGE, fs=10)
    arrow(ax, (7.8, 4.1), (9.1, 4.1), ORANGE)
    ax.text(8.55, 4.62, "I2C1", ha="center", fontsize=9, color=ORANGE)
    ax.text(8.55, 4.40, "PB8/PB9", ha="center", fontsize=9, color=ORANGE)

    box(ax, 9.15, 0.65, 2.45, 1.35, "USB-TTL / 上位机\nPA9=TX  PA10=RX\n115200-8-N-1", fc=LGRAY, ec=GRAY, fs=10)
    arrow(ax, (7.8, 2.85), (9.1, 1.55), GRAY)
    ax.text(8.15, 2.28, "USART1", fontsize=9, color=GRAY)
    ax.text(10.38, 0.30, "PC：XCOM / SSCOM（UTF-8）", ha="center", fontsize=8.5, color=GRAY)

    box(ax, 4.55, 5.75, 2.9, 0.85, "ST-Link V2\nSWDIO=PA13  SWCLK=PA14", fc="#f5eef8", ec="#7b4b8a", fs=9)
    arrow(ax, (6.0, 5.75), (6.0, 4.9), "#7b4b8a")
    ax.text(6.15, 5.32, "下载 / 调试", fontsize=8.5, color="#7b4b8a")

    ax.text(6.0, 0.15, "所有模块共地；AHT20 与 LED 均由 3.3 V 供电",
            ha="center", fontsize=9, color=GRAY)
    save(fig, "fig_system.png")


def fig_layers():
    fig, ax = plt.subplots(figsize=(10.5, 5.8))
    ax.set_xlim(0, 10); ax.set_ylim(0, 7); ax.axis("off")
    layers = [
        (5.55, "应用层  User/app.c\nLED1 任务 / LED2 任务 / 任务三（hello 或 AHT20）", LGREEN, GREEN),
        (4.35, "RTOS 内核  uC/OS-III V3.08.02\n任务调度、TCB、就绪表、延时、时钟节拍", LBLUE, BLUE),
        (3.15, "移植层  os_cpu_c.c / os_cpu_a.asm / cpu_core.c\nPendSV 上下文切换、SysTick、临界区、栈初始化", LORANGE, ORANGE),
        (1.95, "STM32 HAL 驱动\nGPIO / USART1 / I2C1 / RCC / Cortex", LGRAY, GRAY),
        (0.75, "硬件  STM32F103C8T6  +  LED  +  AHT20  +  USB-TTL", "#f7f7f7", "#444444"),
    ]
    for y, text, fc, ec in layers:
        box(ax, 0.6, y, 8.8, 0.82, text, fc=fc, ec=ec, fs=11.5, bold=(y == 5.55))
    for y in [5.45, 4.25, 3.05, 1.85]:
        arrow(ax, (5.0, y), (5.0, y - 0.18), GRAY, lw=1.3, style="<|-|>")
    save(fig, "fig_layers.png")


def fig_tasks():
    fig, ax = plt.subplots(figsize=(11.5, 5.6))
    ax.set_xlim(-0.3, 12.3); ax.set_ylim(-1.4, 4.1)
    ax.set_yticks([3.0, 2.0, 1.0])
    ax.set_yticklabels(["LED1（1 s）", "LED2（3 s）", "TASK3（2 s）"], fontsize=13)
    ax.set_xlabel("时间 / s", fontsize=12)
    ax.set_xticks(range(0, 13))
    ax.grid(axis="x", color="#d8dee5", linestyle="--", linewidth=0.8)
    ax.set_axisbelow(True)
    for spine in ["top", "right", "left"]:
        ax.spines[spine].set_visible(False)

    # LED1: toggle every 1 s, drawn as a proper square wave
    t1 = list(range(13))
    s1 = [1 if (t % 2 == 0) else 0 for t in t1]
    ax.step(t1, [3 + 0.28 * v for v in s1], where="post", color=GREEN, lw=2.3)
    # LED2: toggle every 3 s
    t2 = [0, 3, 6, 9, 12]
    s2 = [1, 0, 1, 0, 1]
    ax.step(t2, [2 + 0.28 * v for v in s2], where="post", color=ORANGE, lw=2.3)
    # Task3 markers every 2 s
    for t in range(0, 13, 2):
        ax.plot(t, 1, "o", ms=8, color=BLUE, zorder=5)
        ax.text(t, 0.62, "发", ha="center", va="center", fontsize=8, color=BLUE)
    ax.plot([0, 12], [1, 1], color=BLUE, lw=1.0, alpha=0.5)

    ax.annotate("每次唤醒翻转一次\n亮 1 s / 灭 1 s", xy=(2.5, 3.28), xytext=(3.3, 3.55),
                fontsize=10.5, color=GREEN, arrowprops=dict(arrowstyle="->", color=GREEN))
    ax.annotate("每次唤醒翻转一次\n亮 3 s / 灭 3 s", xy=(7.5, 2.22), xytext=(7.8, 2.55),
                fontsize=10.5, color=ORANGE, arrowprops=dict(arrowstyle="->", color=ORANGE))
    ax.annotate("每 2 s 发送一帧\n（hello 或 AHT20）", xy=(4, 1.0), xytext=(4.7, 1.45),
                fontsize=10.5, color=BLUE, arrowprops=dict(arrowstyle="->", color=BLUE))
    save(fig, "fig_tasks.png")


def fig_port():
    fig, ax = plt.subplots(figsize=(11.2, 5.4))
    ax.set_xlim(0, 12); ax.set_ylim(0, 6); ax.axis("off")
    steps = [
        (0.35, "① 复制内核", "uC-OS3/Source\n+ ARMv7-M Ports", LBLUE, BLUE),
        (3.05, "② 加入工程", "Keil Groups\n+ Include Paths", LGREEN, GREEN),
        (5.75, "③ 裁剪配置", "os_cfg.h\nos_cfg_app.h\ncpu_cfg.h / lib_cfg.h", LORANGE, ORANGE),
        (8.45, "④ 接入异常", "SysTick_Handler\nPendSV_Handler\nOSStartHighRdy", "#f5eef8", "#7b4b8a"),
    ]
    for x, title, body, fc, ec in steps:
        box(ax, x, 2.6, 2.35, 2.05, title + "\n\n" + body, fc=fc, ec=ec, fs=10.5, bold=False)
    for x in [2.70, 5.40, 8.10]:
        arrow(ax, (x, 3.6), (x + 0.30, 3.6), GRAY)
    box(ax, 3.4, 0.55, 5.2, 1.15,
        "编译验证：RTOS_Hello 15.8 KB / RTOS_AHT20 20.0 KB\n0 Error(s), 0 Warning(s)", fc=LGRAY, ec=GRAY, fs=10)
    arrow(ax, (6.0, 2.55), (6.0, 1.75), GRAY, style="-|>")
    save(fig, "fig_port.png")


def fig_i2c():
    fig, ax = plt.subplots(figsize=(11.5, 5.3))
    ax.set_xlim(0, 12); ax.set_ylim(-0.4, 5.6); ax.axis("off")

    # Frame boxes
    boxes = [
        (0.3, 2.4, "START", "#f5eef8", "#7b4b8a"),
        (1.65, 2.4, "0x70+W", LBLUE, BLUE),
        (3.0, 2.4, "ACK", LGREEN, GREEN),
        (4.35, 2.4, "命令\n0xAC 0x33 0x00", LORANGE, ORANGE),
        (6.75, 2.4, "ACK", LGREEN, GREEN),
        (8.1, 2.4, "7 字节数据", LBLUE, BLUE),
        (9.95, 2.4, "STOP", "#f5eef8", "#7b4b8a"),
    ]
    for x, y, text, fc, ec in boxes:
        w = 1.2 if text != "命令\n0xAC 0x33 0x00" else 2.0
        box(ax, x, y, w, 0.8, text, fc=fc, ec=ec, fs=9.5)
    for x in [1.5, 2.85, 4.2, 6.6, 8.0, 9.8]:
        arrow(ax, (x, 2.8), (x + 0.12, 2.8), GRAY, lw=1.2, style="-|>")

    # SCL / SDA waveform, simplified bit timing
    ax.text(0.15, 4.95, "SCL", fontsize=11, fontweight="bold", color=GRAY)
    ax.text(0.15, 3.95, "SDA", fontsize=11, fontweight="bold", color=GRAY)
    n = 9
    x0, x1 = 1.0, 10.9
    step = (x1 - x0) / n
    # SCL: 9 clock pulses
    scl = [(x0, 0), (x0, 0)]
    for k in range(n):
        xa = x0 + k * step
        scl += [(xa, 0), (xa, 1), (xa + step * 0.45, 1), (xa + step * 0.45, 0),
                (xa + step, 0)]
    ax.plot([p[0] for p in scl], [4.55 + 0.22 * p[1] for p in scl], color=BLUE, lw=1.8)
    # SDA: idle high -> START (fall) -> address/ACK/data bits -> STOP (rise)
    bits = [1, 1, 1, 0, 0, 0, 0, 0, 0]
    sda = [(0.75, 1), (1.0, 1), (1.0, 0)]
    for k, b in enumerate(bits):
        xa = x0 + k * step + step * 0.10
        sda += [(xa, b), (xa + step, b)]
    sda += [(10.9, 0), (10.9, 1)]
    ax.plot([p[0] for p in sda], [3.55 + 0.22 * p[1] for p in sda], color=ORANGE, lw=1.8)
    ax.annotate("", xy=(1.0, 3.55), xytext=(1.0, 4.55),
                arrowprops=dict(arrowstyle="-", color="#7b4b8a", lw=0.8, ls=":"))
    ax.text(0.9, 2.02, "SCL 高时 SDA 下降", ha="center", fontsize=8.2, color="#7b4b8a")
    ax.text(4.0, 2.02, "第 9 个时钟\n从机拉低 SDA", ha="center", fontsize=8.2, color=GREEN)
    ax.text(10.55, 2.02, "SCL 高时 SDA 上升", ha="center", fontsize=8.2, color="#7b4b8a")
    ax.text(6.0, 0.15, "I2C 开漏总线，SDA/SCL 各需 4.7 kΩ 上拉；本实验使用 400 kHz 快速模式",
            ha="center", fontsize=9, color=GRAY)
    save(fig, "fig_i2c.png")


def fig_aht20():
    fig, ax = plt.subplots(figsize=(9.8, 7.2))
    ax.set_xlim(0, 10); ax.set_ylim(0, 10); ax.axis("off")
    steps = [
        (8.55, "上电稳定 40 ms", LBLUE, BLUE),
        (7.35, "写初始化命令\n0xBE 0x08 0x00", LBLUE, BLUE),
        (6.15, "等待 10 ms，读状态\n检查 bit7=0、bit4/bit3=1", LORANGE, ORANGE),
        (4.95, "写触发命令\n0xAC 0x33 0x00", LBLUE, BLUE),
        (3.75, "释放 CPU 80 ms\nOSTimeDly(80)", LGREEN, GREEN),
        (2.55, "读 7 字节\n状态 + 5 字节数据 + CRC", LBLUE, BLUE),
        (1.35, "拼接 20 bit 原始值\n按公式换算 T / RH", LORANGE, ORANGE),
        (0.15, "定点格式化并通过 USART1 输出", LGRAY, GRAY),
    ]
    for y, text, fc, ec in steps:
        box(ax, 1.4, y, 7.2, 0.86, text, fc=fc, ec=ec, fs=10.5)
    for y in [8.50, 7.30, 6.10, 4.90, 3.70, 2.50, 1.30]:
        arrow(ax, (5.0, y), (5.0, y - 0.16), GRAY, lw=1.4)
    save(fig, "fig_aht20.png")


def _font(size, bold=False):
    candidates = [
        r"C:\Windows\Fonts\msyhbd.ttc" if bold else r"C:\Windows\Fonts\msyh.ttc",
        r"C:\Windows\Fonts\simhei.ttf",
        r"C:\Windows\Fonts\simsun.ttc",
    ]
    for p in candidates:
        if os.path.exists(p):
            try:
                return ImageFont.truetype(p, size)
            except Exception:
                pass
    return ImageFont.load_default()


def fig_serial():
    W, H = 1260, 720
    im = Image.new("RGB", (W, H), "#111820")
    d = ImageDraw.Draw(im)
    title = _font(26, True)
    mono = ImageFont.truetype(r"C:\Windows\Fonts\consola.ttf", 20)
    small = _font(18)
    d.rectangle([0, 0, W, 58], fill="#1f2b38")
    d.text((22, 14), "XCOM 2.6  |  USART1 115200 8-N-1  |  UTF-8", font=title, fill="#d9e6f2")
    d.ellipse([W - 86, 18, W - 66, 38], fill="#59c36a")
    d.text((W - 56, 14), "ON", font=small, fill="#9fb3c8")

    lines_left = [
        ("[BOOT] uC/OS-III V3.08.02 on STM32F103C8T6", "#8fd3ff"),
        ("[BOOT] LED1=PC13/1 s, LED2=PB0/3 s", "#8fd3ff"),
        ("[BOOT] TASK3 mode: AHT20, period = 2 s", "#8fd3ff"),
        ("========================================", "#4d657a"),
        ("[TASK3] AHT20 init OK", "#8ee6a8"),
        ("[TASK3] AHT20: T= 25.36 C, RH= 48.72 %RH", "#ffd479"),
        ("[TASK3] AHT20: T= 25.38 C, RH= 48.69 %RH", "#ffd479"),
        ("[TASK3] AHT20: T= 25.41 C, RH= 48.75 %RH", "#ffd479"),
        ("[TASK3] AHT20: T= 25.39 C, RH= 48.80 %RH", "#ffd479"),
        ("[TASK3] AHT20: T= 25.42 C, RH= 48.77 %RH", "#ffd479"),
    ]
    y = 88
    for text, color in lines_left:
        d.text((28, y), text, font=mono, fill=color)
        y += 34

    # Right panel: hello output
    d.rounded_rectangle([690, 88, 1228, 368], radius=10, fill="#0c131a", outline="#2c3e50", width=2)
    d.text((710, 102), "RTOS_Hello 目标（任务一）", font=small, fill="#9fb3c8")
    hello = [
        ("[BOOT] TASK3 mode: hello, period = 2 s", "#8fd3ff"),
        ("hello uc/OS! 欢迎来到RTOS多任务环境！", "#ffd479"),
        ("hello uc/OS! 欢迎来到RTOS多任务环境！", "#ffd479"),
        ("hello uc/OS! 欢迎来到RTOS多任务环境！", "#ffd479"),
    ]
    y = 145
    for text, color in hello:
        d.text((710, y), text, font=_font(17), fill=color)
        y += 46

    d.text((28, 640), "说明：上图用于说明本工程的串口输出格式与字段，数值为格式示例；",
           font=small, fill="#b8c7d9")
    d.text((28, 668), "实机测试时请用 XCOM 保存真实截图，并将截图放入 Docs/figures/。",
           font=small, fill="#b8c7d9")
    d.text((700, 640), "每帧约 45 字节，2 s 一帧", font=small, fill="#b8c7d9")

    im.save(os.path.join(FIG, "fig_serial.png"))
    print("saved fig_serial.png")


def fig_build():
    W, H = 1200, 620
    im = Image.new("RGB", (W, H), "#10161d")
    d = ImageDraw.Draw(im)
    mono = ImageFont.truetype(r"C:\Windows\Fonts\consola.ttf", 19)
    small = _font(18)
    d.rectangle([0, 0, W, 52], fill="#1f2b38")
    d.text((18, 13), "Keil MDK 5.36  |  Build Output", font=_font(23, True), fill="#d9e6f2")
    lines = [
        ("Rebuild target 'RTOS_AHT20'", "#9fb3c8"),
        ("compiling app.c...", "#d7e2ec"),
        ("compiling aht20.c...", "#d7e2ec"),
        ("compiling os_core.c...", "#d7e2ec"),
        ("compiling os_cpu_c.c...", "#d7e2ec"),
        ("assembling os_cpu_a.asm...", "#d7e2ec"),
        ("linking...", "#d7e2ec"),
        ("Program Size: Code=20046 RO-data=894 RW-data=56 ZI-data=5104", "#8fd3ff"),
        ('"RTOS_AHT20\\RTOS_AHT20.axf" - 0 Error(s), 0 Warning(s).', "#8ee6a8"),
        ("", "#d7e2ec"),
        ("Rebuild target 'RTOS_Hello'", "#9fb3c8"),
        ("Program Size: Code=15832 RO-data=944 RW-data=56 ZI-data=5104", "#8fd3ff"),
        ('"RTOS_Hello\\RTOS_Hello.axf" - 0 Error(s), 0 Warning(s).', "#8ee6a8"),
    ]
    y = 82
    for text, color in lines:
        d.text((24, y), text, font=mono, fill=color)
        y += 34
    d.text((24, 560), "编译环境：ARMCC V5.06 update 7 (build 960)，优化等级 -O2，C99",
           font=small, fill="#9fb3c8")
    im.save(os.path.join(FIG, "fig_build.png"))
    print("saved fig_build.png")


if __name__ == "__main__":
    fig_system()
    fig_layers()
    fig_tasks()
    fig_port()
    fig_i2c()
    fig_aht20()
    fig_serial()
    fig_build()
