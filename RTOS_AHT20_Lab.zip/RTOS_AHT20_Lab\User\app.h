/**
  ******************************************************************************
  * @file    app.h
  * @brief   应用初始化与 uC/OS-III 启动接口
  ******************************************************************************
  */
#ifndef __APP_H
#define __APP_H

#ifdef __cplusplus
extern "C" {
#endif

void App_Init(void);
void App_Start(void);

#ifdef __cplusplus
}
#endif

#endif /* __APP_H */
