﻿# -*- coding: utf-8 -*-
"""Convert 实验报告.md (a controlled Markdown subset) to XeLaTeX and build the PDF.

Supported: #/##/###/####, paragraphs, - lists, 1. lists, pipe tables,
fenced code, ![alt](path) figures, $$math$$, <!-- pagebreak -->,
**bold**, `code`, [text](url).

Images are copied into build/figs with ASCII names so XeLaTeX never has to deal
with Chinese path names.
"""
import os
import re
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
MD = os.path.join(ROOT, "Lab_Report.md")
BUILD = os.path.join(ROOT, "build")
FIGS = os.path.join(BUILD, "figs")

XELATEX = r"D:\texlive\2025\bin\windows\xelatex.exe"


def tex_escape(s):
    out = []
    for ch in s:
        if ch == "\\":
            out.append(r"\textbackslash{}")
        elif ch in "&%$#_{}":
            out.append("\\" + ch)
        elif ch == "~":
            out.append(r"\textasciitilde{}")
        elif ch == "^":
            out.append(r"\textasciicircum{}")
        else:
            out.append(ch)
    return "".join(out)


INLINE_CODE = re.compile(r"`([^`]+)`")
MATH = re.compile(r"\$([^$]+)\$")


def inline(s):
    """Markdown inline -> LaTeX, protecting math and inline code."""
    pieces = []
    pos = 0
    token = re.compile(r"(`[^`]*`|\$[^$]*\$)")

    def fmt_text(t):
        t = tex_escape(t)
        t = re.sub(r"\*\*(.+?)\*\*", r"\\textbf{\1}", t)
        t = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r"\\href{\2}{\1}", t)
        return t

    for m in token.finditer(s):
        pieces.append(fmt_text(s[pos:m.start()]))
        chunk = m.group(0)
        if chunk.startswith("`"):
            code = tex_escape(chunk[1:-1])
            code = code.replace(r"\_", r"\_\allowbreak{}").replace("/", r"/\allowbreak{}")
            pieces.append(r"\texttt{%s}" % code)
        else:
            pieces.append("$" + chunk[1:-1] + "$")
        pos = m.end()
    pieces.append(fmt_text(s[pos:]))
    return "".join(pieces)


def parse_table(lines):
    rows = []
    for ln in lines:
        ln = ln.strip()
        if ln.startswith("|"):
            ln = ln[1:]
        if ln.endswith("|"):
            ln = ln[:-1]
        rows.append([c.strip() for c in ln.split("|")])
    if len(rows) >= 2 and re.match(r"^:?-{2,}", rows[1][0].replace(" ", "")):
        return rows[0], rows[2:]
    return rows[0], rows[1:]


def table_tex(rows, header):
    n = len(header)
    wide_numeric = n >= 6
    if wide_numeric:
        spec = "@{}l" + "r" * (n - 1) + "@{}"
    elif n == 2:
        spec = "@{}lX@{}"
    else:
        spec = "@{}l" + "X" * (n - 1) + "@{}"
    size = r"\footnotesize" if n >= 4 else r"\small"
    out = []
    out.append(r"\begin{table}[H]\centering")
    out.append(size)
    out.append(r"\renewcommand{\arraystretch}{1.28}")
    out.append((r"\begin{tabular}{%s}" if wide_numeric else r"\begin{tabularx}{\textwidth}{%s}") % spec)
    out.append(r"\toprule")
    out.append(" & ".join(r"\textbf{%s}" % inline(c) for c in header) + r" \\")
    out.append(r"\midrule")
    for r in rows:
        r = (r + [""] * n)[:n]
        out.append(" & ".join(inline(c) for c in r) + r" \\")
    out.append(r"\bottomrule")
    out.append(r"\end{tabular}" if wide_numeric else r"\end{tabularx}")
    out.append(r"\end{table}")
    return "\n".join(out)


def blocks_from(md_text):
    lines = md_text.splitlines()
    blocks = []
    i = 0
    n = len(lines)
    while i < n:
        line = lines[i]
        s = line.strip()
        if not s:
            i += 1
            continue
        if s == "<!-- pagebreak -->":
            blocks.append(("pagebreak", None)); i += 1; continue
        if s.startswith("# "):
            blocks.append(("h1", s[2:].strip())); i += 1; continue
        if s.startswith("## "):
            blocks.append(("h2", s[3:].strip())); i += 1; continue
        if s.startswith("### "):
            blocks.append(("h3", s[4:].strip())); i += 1; continue
        if s.startswith("#### "):
            blocks.append(("h4", s[5:].strip())); i += 1; continue
        if s.startswith("```"):
            lang = s[3:].strip()
            j = i + 1
            code = []
            while j < n and not lines[j].strip().startswith("```"):
                code.append(lines[j]); j += 1
            blocks.append(("code", (lang, code))); i = j + 1; continue
        if s.startswith("|"):
            j = i
            tl = []
            while j < n and lines[j].strip().startswith("|"):
                tl.append(lines[j]); j += 1
            header, rows = parse_table(tl)
            blocks.append(("table", (header, rows))); i = j; continue
        if s.startswith("- "):
            items = []
            j = i
            while j < n and lines[j].strip().startswith("- "):
                items.append(lines[j].strip()[2:].strip()); j += 1
            blocks.append(("ul", items)); i = j; continue
        if re.match(r"^\d+\.\s", s):
            items = []
            j = i
            while j < n and re.match(r"^\d+\.\s", lines[j].strip()):
                items.append(re.sub(r"^\d+\.\s*", "", lines[j].strip())); j += 1
            blocks.append(("ol", items)); i = j; continue
        if s.startswith("!["):
            m = re.match(r"!\[([^\]]*)\]\(([^)]+)\)", s)
            blocks.append(("img", (m.group(1), m.group(2)))); i += 1; continue
        if s.startswith("$$"):
            body = s.strip("$")
            blocks.append(("math", body)); i += 1; continue
        # paragraph
        para = [s]
        j = i + 1
        while j < n and lines[j].strip() and not re.match(r"^(#|\||- |\d+\.\s|```|!\[|<!--|\$\$)", lines[j].strip()):
            para.append(lines[j].strip()); j += 1
        blocks.append(("p", " ".join(para)))
        i = j
    return blocks


PREAMBLE = r"""\documentclass[UTF8,a4paper,11pt]{ctexart}
\usepackage{geometry}
\geometry{left=2.35cm,right=2.35cm,top=2.6cm,bottom=2.3cm}
\usepackage{graphicx,float,booktabs,tabularx,array}
\usepackage{xcolor}
\usepackage{listings}
\usepackage{amsmath}
\usepackage{fancyhdr}
\usepackage{caption}
\usepackage{enumitem}
\usepackage[hidelinks]{hyperref}
\sloppy

\captionsetup{font=small,labelsep=quad}
\renewcommand{\figurename}{图}
\renewcommand{\tablename}{表}
\ctexset{
  section/name={,、},
  section/number=\chinese{section},
  subsection/number=\arabic{section}.\arabic{subsection},
  subsubsection/number=\arabic{section}.\arabic{subsection}.\arabic{subsubsection}
}
\linespread{1.26}
\setlength{\parskip}{0.26em}
\pagestyle{fancy}
\fancyhf{}
\fancyhead[L]{\small\color{gray} STM32F103 uC/OS-III 与 AHT20 实验报告}
\fancyhead[R]{\small\color{gray} 吴勇锋\quad 632407030509}
\fancyfoot[C]{\small\thepage}
\renewcommand{\headrulewidth}{0.4pt}
\lstset{basicstyle=\ttfamily\small,breaklines=true,columns=fullflexible,
        backgroundcolor=\color{gray!8},frame=single,rulecolor=\color{gray!45},
        xleftmargin=1em,xrightmargin=1em,aboveskip=0.9em,belowskip=0.9em,
        showstringspaces=false}
\setlist{itemsep=0.15em,topsep=0.25em}
\graphicspath{{figs/}}
"""


def build():
    os.makedirs(FIGS, exist_ok=True)
    md = open(MD, encoding="utf-8-sig").read()
    blocks = blocks_from(md)

    title = "实验报告"
    cover_rows = []
    start = 0
    if blocks and blocks[0][0] == "h1":
        title = blocks[0][1]
        start = 1
    if len(blocks) > 1 and blocks[1][0] == "table":
        cover_rows = blocks[1][1][1]
        start = 2
    # drop the .ioc table? no

    out = [PREAMBLE, r"\begin{document}", r"\begin{titlepage}", r"\centering"]
    out.append(r"\vspace*{2.2cm}")
    out.append(r"{\LARGE\bfseries %s\par}" % tex_escape(title))
    out.append(r"\vspace{0.8cm}")
    out.append(r"{\LARGE 实验报告\par}")
    out.append(r"\vspace{2.2cm}")
    if cover_rows:
        out.append(r"{\large")
        out.append(r"\renewcommand{\arraystretch}{1.5}")
        out.append(r"\begin{tabular}{r@{\hspace{1.2em}}l}")
        for r in cover_rows:
            if len(r) >= 2:
                out.append(r"\textcolor{gray}{%s} & %s \\" % (tex_escape(r[0]), inline(r[1])))
        out.append(r"\end{tabular}}")
    out.append(r"\vfill")
    out.append(r"{\large 2026 年 10 月\par}")
    out.append(r"\end{titlepage}")

    out.append(r"\newpage")
    out.append(r"\setcounter{tocdepth}{1}")
    out.append(r"\tableofcontents")
    out.append(r"\newpage")

    fig_no = 0
    for kind, data in blocks[start:]:
        if kind == "h2":
            if data.startswith("附录"):
                t = inline(data)
                out.append(r"\section*{%s}" % t)
                out.append(r"\addcontentsline{toc}{section}{%s}" % t)
            else:
                out.append(r"\section{%s}" % inline(data))
        elif kind == "h3":
            out.append(r"\subsection{%s}" % inline(data))
        elif kind == "h4":
            out.append(r"\subsubsection{%s}" % inline(data))
        elif kind == "p":
            out.append(inline(data) + "\n")
        elif kind == "ul":
            out.append(r"\begin{itemize}")
            for it in data:
                out.append(r"  \item %s" % inline(it))
            out.append(r"\end{itemize}")
        elif kind == "ol":
            out.append(r"\begin{enumerate}")
            for it in data:
                out.append(r"  \item %s" % inline(it))
            out.append(r"\end{enumerate}")
        elif kind == "table":
            out.append(table_tex(data[1], data[0]))
        elif kind == "code":
            lang, code = data
            out.append(r"\begin{lstlisting}")
            out.extend(code)
            out.append(r"\end{lstlisting}")
        elif kind == "math":
            out.append(r"\[ %s \]" % data)
        elif kind == "pagebreak":
            out.append(r"\newpage")
        elif kind == "img":
            alt, path = data
            src = os.path.join(ROOT, path.replace("/", os.sep))
            if not os.path.exists(src):
                print("missing image:", src)
                continue
            fig_no += 1
            ext = os.path.splitext(src)[1].lower()
            dst = os.path.join(FIGS, "fig%02d%s" % (fig_no, ext))
            shutil.copyfile(src, dst)
            out.append(r"\begin{figure}[H]")
            out.append(r"\centering")
            out.append(r"\includegraphics[width=0.97\textwidth,height=0.66\textheight,keepaspectratio]{fig%02d%s}"
                       % (fig_no, ext))
            out.append(r"\caption{%s}" % inline(alt))
            out.append(r"\end{figure}")

    out.append(r"\end{document}")
    tex = "\n".join(out)
    tex_path = os.path.join(BUILD, "report.tex")
    open(tex_path, "w", encoding="utf-8", newline="\n").write(tex)

    env = dict(os.environ)
    env["TEXMFVAR"] = os.path.join(BUILD, "texmfvar")
    env["TEXMFCACHE"] = os.path.join(BUILD, "texmfcache")
    for _ in range(2):
        p = subprocess.run([XELATEX, "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
                           cwd=BUILD, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if p.returncode != 0:
            print("xelatex failed, see build/report.log")
            log = open(os.path.join(BUILD, "report.log"), encoding="utf-8", errors="ignore").read()
            for line in log.splitlines():
                if line.startswith("!") or "Error" in line:
                    print(line)
            sys.exit(1)

    pdf = os.path.join(BUILD, "report.pdf")
    if os.path.exists(pdf):
        shutil.copyfile(pdf, os.path.join(ROOT, "Lab_Report.pdf"))
        print("pdf ->", os.path.join(ROOT, "Lab_Report.pdf"), os.path.getsize(pdf), "bytes")
    else:
        print("no pdf produced")
        sys.exit(1)


if __name__ == "__main__":
    build()
