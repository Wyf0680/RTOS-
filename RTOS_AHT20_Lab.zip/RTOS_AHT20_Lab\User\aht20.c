/**
  ******************************************************************************
  * @file    aht20.c
  * @brief   AHT20 温湿度传感器驱动实现
  *
  *  时序（AHT20 数据手册）：
  *    上电 40 ms
  *      -> 写 0xBE 0x08 0x00 初始化/校准
  *      -> 读状态，bit4=1 表示已校准，bit3=1 表示校准使能
  *      -> 写 0xAC 0x33 0x00 触发测量
  *      -> 等待 75~80 ms
  *      -> 读 7 字节：状态 + 5 字节数据 + CRC
  *
  *  数据换算：
  *    RH  = raw_h / 2^20 * 100 %RH
  *    T   = raw_t / 2^20 * 200 - 50 ℃
  ******************************************************************************
  */
#include "aht20.h"
#include "i2c.h"
#include <stddef.h>

#define AHT20_CMD_INIT      0xBEu
#define AHT20_CMD_TRIGGER   0xACu
#define AHT20_I2C_TIMEOUT   100u

static uint8_t AHT20_WriteCommand(const uint8_t *cmd, uint16_t len)
{
    if (HAL_I2C_Master_Transmit(&hi2c1, AHT20_I2C_ADDR,
                                (uint8_t *)cmd, len, AHT20_I2C_TIMEOUT) != HAL_OK) {
        return 0u;
    }
    return 1u;
}

uint8_t AHT20_Init(void)
{
    uint8_t cmd[3] = {AHT20_CMD_INIT, 0x08u, 0x00u};
    uint8_t status = 0u;

    HAL_Delay(40u);                     /* 上电稳定时间 */

    if (AHT20_WriteCommand(cmd, sizeof(cmd)) == 0u) {
        return 0u;
    }
    HAL_Delay(10u);                     /* 等校准完成 */

    if (HAL_I2C_Master_Receive(&hi2c1, AHT20_I2C_ADDR,
                               &status, 1u, AHT20_I2C_TIMEOUT) != HAL_OK) {
        return 0u;
    }

    /* bit7 = busy，bit4 = calibrated，bit3 = calibration enabled */
    if ((status & 0x80u) != 0u) {
        return 0u;
    }
    return ((status & 0x18u) == 0x18u) ? 1u : 0u;
}

uint8_t AHT20_StartMeasurement(void)
{
    uint8_t cmd[3] = {AHT20_CMD_TRIGGER, 0x33u, 0x00u};
    return AHT20_WriteCommand(cmd, sizeof(cmd));
}

uint8_t AHT20_ReadMeasurement(float *temperature, float *humidity)
{
    uint8_t buf[7] = {0};
    uint32_t raw_h;
    uint32_t raw_t;

    if ((temperature == NULL) || (humidity == NULL)) {
        return 0u;
    }

    if (HAL_I2C_Master_Receive(&hi2c1, AHT20_I2C_ADDR,
                               buf, sizeof(buf), AHT20_I2C_TIMEOUT) != HAL_OK) {
        return 0u;
    }

    if ((buf[0] & 0x80u) != 0u) {       /* 忙，数据无效 */
        return 0u;
    }

    raw_h = ((uint32_t)buf[1] << 12) |
            ((uint32_t)buf[2] << 4)  |
            ((uint32_t)buf[3] >> 4);

    raw_t = (((uint32_t)buf[3] & 0x0Fu) << 16) |
            ((uint32_t)buf[4] << 8)            |
             (uint32_t)buf[5];

    *humidity    = (float)raw_h * 100.0f / 1048576.0f;
    *temperature = (float)raw_t * 200.0f / 1048576.0f - 50.0f;

    return 1u;
}
