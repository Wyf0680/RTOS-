/**
  ******************************************************************************
  * @file    led.c
  * @brief   LED 控制实现（低电平点亮）
  ******************************************************************************
  */
#include "led.h"
#include "main.h"

void LED_Init(void)
{
    /* MX_GPIO_Init() 已把两个引脚配置为推挽输出，这里只把它们置为熄灭状态。
       低电平点亮，所以高电平为熄灭。 */
    HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_SET);
}

void LED_On(uint8_t id)
{
    if (id == LED_ID_1) {
        HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_RESET);
    } else if (id == LED_ID_2) {
        HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_RESET);
    }
}

void LED_Off(uint8_t id)
{
    if (id == LED_ID_1) {
        HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_SET);
    } else if (id == LED_ID_2) {
        HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_SET);
    }
}

void LED_Toggle(uint8_t id)
{
    if (id == LED_ID_1) {
        HAL_GPIO_TogglePin(LED1_GPIO_Port, LED1_Pin);
    } else if (id == LED_ID_2) {
        HAL_GPIO_TogglePin(LED2_GPIO_Port, LED2_Pin);
    }
}
