﻿# STM32F103 的 uC/OS-III 移植与 AHT20 温湿度采集

| 项目 | 内容 |
|------|------|
| 课程 | 嵌入式系统实验 |
| 题目 | uC/OS-III 移植、多任务 LED 与 I2C AHT20 数据采集 |
| 姓名 | 吴勇锋 |
| 学号 | 632407030509 |
| 班级 | 通信工程 2 班 |
| 实验室 | 物联网 205 实训室 |
| 硬件 | STM32F103C8T6 最小系统板、AHT20、2 只 LED、USB-TTL、ST-Link V2 |
| 软件 | STM32CubeMX 6.18.1、Keil MDK 5.36、STM32Cube FW_F1 V1.8.7、VSCode |
| 日期 | 2026 年 10 月 28 日 |

## 实验目的

本实验把课堂中的 RTOS 概念落到一块真实的 Cortex-M3 芯片上，完成从裸机程序到多任务程序的迁移，并在此基础上接入 I2C 传感器。具体目标如下。

1. 理解嵌入式实时操作系统的基本组成：任务、任务控制块、就绪表、调度器、系统节拍、上下文切换和临界区。
2. 掌握 uC/OS-III 在 STM32F103 上的移植方法，能够独立完成源码裁剪、工程配置、SysTick 与 PendSV 的接入。
3. 使用 uC/OS-III 建立至少三个周期任务，验证 1 s、3 s、2 s 三种不同节拍的并发运行。
4. 理解 I2C 总线的物理层与协议层，能够区分软件 I2C 与硬件 I2C，并能阅读 AHT20 数据手册完成驱动编写。
5. 把任务三改造成“每 2 s 采集一次 AHT20 并通过串口上报”，比较裸机阻塞式写法与 RTOS 非阻塞写法的差异。
6. 学会使用 STM32CubeMX 建立工程、使用 Keil 编译下载、使用串口助手观察运行结果，并用 Markdown 记录完整过程。

## 实验环境与硬件连接

### 硬件平台

| 器件 | 型号与参数 | 作用 |
|------|------------|------|
| 主控 | STM32F103C8T6，Cortex-M3，72 MHz，64 KB Flash，20 KB RAM | 运行 uC/OS-III 与应用程序 |
| 传感器 | AHT20，I2C 接口，7 位地址 0x38，3.3 V 供电 | 采集温度与相对湿度 |
| 显示/指示 | LED1 为板载 PC13 LED，LED2 为外接 PB0 LED | 观察两个任务的运行节拍 |
| 串口 | USB-TTL（CH340 或 CP2102），PA9=TX，PA10=RX | 向上位机输出 hello 或温湿度 |
| 下载器 | ST-Link V2，SWDIO=PA13，SWCLK=PA14 | 下载、调试、复位 |
| 电源 | 3.3 V，所有模块共地 | 给主控、AHT20、LED 供电 |

### 软件工具

| 工具 | 版本 | 用途 |
|------|------|------|
| STM32CubeMX | 6.18.1 | 配置时钟、GPIO、USART1、I2C1，生成 HAL 工程骨架 |
| STM32Cube FW_F1 | V1.8.7 | STM32F1 的 HAL 库、CMSIS 与启动文件 |
| Keil MDK | 5.36，ARMCC V5.06 update 7 | 编译、链接、下载与在线调试 |
| uC/OS-III | V3.08.02 | 实时内核 |
| uC/CPU | V1.32.01 | Cortex-M 内核移植层与 CPU 统计 |
| uC/LIB | V1.39.01 | 字符串、内存、数学等基础库 |
| VSCode | 1.9x | 编写 Markdown 报告、查看源码 |
| Python + Pillow/Matplotlib | 3.x | 生成报告插图、打包辅助 |

### 引脚分配与接线

| 模块 | 模块引脚 | 接到 STM32F103C8T6 | 说明 |
|------|----------|--------------------|------|
| LED1 | 阳极经 330 Ω 到 3.3 V，阴极到 PC13 | PC13 | 板载 LED，低电平点亮 |
| LED2 | 阳极经 330 Ω 到 3.3 V，阴极到 PB0 | PB0 | 外接 LED，低电平点亮 |
| AHT20 | VCC / GND | 3.3 V / GND | 不要接 5 V |
| AHT20 | SCL / SDA | PB8 / PB9 | I2C1 重映射，模块自带 4.7 kΩ 上拉时可直接并联 |
| USB-TTL | RXD / TXD | PA9 / PA10 | 交叉连接：模块 RXD 接 PA9，模块 TXD 接 PA10 |
| ST-Link | SWDIO / SWCLK / GND / 3.3 V | PA13 / PA14 / GND / 3.3 V | 下载与调试 |
| 公共 | GND | GND | 所有模块必须共地 |

这里要特别说明 LED 的“周期”含义。任务每次被唤醒时翻转一次 LED，因此任务周期为 1 s 时，肉眼看到的完整亮灭周期是 2 s；任务周期为 3 s 时，完整亮灭周期是 6 s。实验报告中的“1 s 任务”“3 s 任务”均指任务唤醒周期，而不是完整闪烁周期。这样做的好处是任务体只做一次 GPIO 翻转，周期由 `OSTimeDly()` 精确控制，便于用逻辑分析仪测量任务节拍。

![系统总体框图](figures/fig_system.png)

## 实时操作系统与 uC/OS-III 基本原理

### 为什么需要 RTOS

裸机程序通常由一个超级循环加若干中断组成，所有功能按顺序排队执行。只要某个环节使用 `HAL_Delay()` 或忙等，整个系统就会被阻塞，按键、串口和传感器只能轮流等待。RTOS 把不同功能拆成独立的任务，每个任务拥有自己的栈和优先级，由调度器决定当前运行哪个任务。一个任务在等待延时、信号量或事件时主动让出 CPU，其他任务即可运行，从而获得“并发”的效果。

RTOS 的“实时”并不等于“运行得快”，而是指系统能够在确定的时间内响应事件。uC/OS-III 是可剥夺的优先级调度内核：高优先级任务一旦就绪，就能立即打断低优先级任务；同优先级任务可以配置时间片轮转。对于本实验这种三个周期任务，优先级调度已经足够。

### 任务、TCB 与任务状态

任务是 RTOS 调度的基本单位。每个任务有独立的入口函数、优先级、栈和任务控制块（TCB）。TCB 记录任务栈顶指针、优先级、状态、延时剩余节拍、等待对象等信息。任务在运行过程中会在以下几种状态之间迁移。

| 状态 | 含义 | 进入方式 |
|------|------|----------|
| 就绪 | 具备运行条件，等待调度器选中 | 创建完成、延时到期、事件到达 |
| 运行 | 当前占用 CPU | 调度器选中 |
| 延时/等待 | 主动让出 CPU，等待时间或事件 | `OSTimeDly()`、等待信号量等 |
| 挂起 | 被显式暂停 | `OSTaskSuspend()` |
| 休眠/删除 | 任务不再参与调度 | 删除或未创建 |

本实验的三个任务都只使用“就绪—运行—延时”三种状态。任务执行完一次动作后调用 `OSTimeDly()`，内核把它从就绪表移到节拍延时链表；SysTick 每 1 ms 递减延时计数，减到 0 时再把任务放回就绪表。

### 系统节拍与上下文切换

uC/OS-III 需要一个周期性的时钟节拍，本实验使用 1 kHz，即每 1 ms 一次 SysTick 中断。节拍中断中完成两件事：一是调用 `OSTimeTick()` 更新所有延时任务；二是在需要时触发 PendSV，完成任务上下文切换。

Cortex-M3 的上下文切换利用硬件自动压栈和软件手动压栈相结合的方式。进入异常时，硬件自动把 R0-R3、R12、LR、PC、xPSR 压入当前任务的栈；PendSV 处理程序再保存 R4-R11，并切换栈指针。恢复时相反。由于 PendSV 的优先级被设置为最低，它可以被其他中断打断，从而避免在中断嵌套过程中做上下文切换。

### uC/OS-III 的源码组成

本实验使用 Weston Embedded 维护的官方开源版本，版本号为 V3.08.02，许可证为 Apache-2.0。工程中实际使用的源码分为三部分。

| 目录 | 主要内容 | 作用 |
|------|----------|------|
| `Middlewares/uC-OS3/Source` | `os_core.c`、`os_task.c`、`os_tick.c`、`os_time.c` 等 | 内核主体 |
| `Middlewares/uC-OS3/Ports/ARM-Cortex-M/ARMv7-M` | `os_cpu_c.c`、`os_cpu_a.asm`、`os_cpu.h` | Cortex-M3 移植层 |
| `Middlewares/uC-CPU` | `cpu_core.c`、`cpu_c.c`、`cpu_a.asm`、`cpu.h` | CPU 底层操作、临界区、位操作 |
| `Middlewares/uC-LIB` | `lib_ascii.c`、`lib_math.c`、`lib_mem.c`、`lib_str.c` | 内核依赖的基础库 |
| `Middlewares/uC-OS3/Cfg` | `os_cfg.h`、`os_cfg_app.h` | 内核裁剪配置 |
| `Middlewares/uC-CPU/Cfg` | `cpu_cfg.h` | CPU 配置 |
| `Middlewares/uC-LIB/Cfg` | `lib_cfg.h` | 基础库配置 |

![软件分层与移植边界](figures/fig_layers.png)

## STM32CubeMX 工程建立

### 新建工程与时钟配置

打开 STM32CubeMX，选择 `File -> New Project`，在芯片选择框中输入 `STM32F103C8T6`，选择 LQFP48 封装。进入 Pinout 视图后，先配置系统时钟。

| 配置项 | 取值 | 说明 |
|--------|------|------|
| RCC HSE | Crystal/Ceramic Resonator | 外部 8 MHz 晶振 |
| PLL Source | HSE | 8 MHz 输入 |
| PLL Mul | ×9 | 得到 72 MHz |
| SYSCLK | PLLCLK | 72 MHz |
| AHB Prescaler | /1 | HCLK=72 MHz |
| APB1 Prescaler | /2 | PCLK1=36 MHz，I2C1 挂载在此 |
| APB2 Prescaler | /1 | PCLK2=72 MHz，USART1 挂载在此 |
| Debug | Serial Wire | 保留 PA13/PA14，使用 SWD |

APB1 的时钟上限是 36 MHz，因此 I2C1 的时钟源为 36 MHz；HAL 会根据该频率计算 400 kHz 的 CCR 值。APB2 为 72 MHz，USART1 的波特率计算也以 72 MHz 为基准。

### GPIO 配置

在 Pinout 视图中把 PC13 配置为 `GPIO_Output`，标签设为 `LED1`；把 PB0 配置为 `GPIO_Output`，标签设为 `LED2`。两个引脚都设置为推挽输出、无上下拉、低速。由于 LED 是低电平点亮，程序初始化时先把两个引脚置高，使 LED 熄灭，再由任务翻转。

### USART1 配置

选择 `Connectivity -> USART1`，模式设为 `Asynchronous`，引脚为 PA9/PA10。参数设置为 115200 bit/s、8 位数据、无校验、1 位停止位、无硬件流控。本实验采用轮询发送，不开启 USART1 中断，因此不需要配置 USART1 的 NVIC 优先级。这样做的原因是每 2 s 才发送约 45 字节，115200 bit/s 下耗时约 4 ms，轮询完全足够，且可以减少中断嵌套带来的调试复杂度。

### I2C1 配置

选择 `Connectivity -> I2C1`，模式设为 `I2C`，速度设为 `Fast Mode`，Clock Speed 为 400000 Hz，7 位地址模式。STM32F103 的 I2C1 默认引脚是 PB6/PB7，本实验使用 PB8/PB9，因此需要在 `HAL_I2C_MspInit()` 中调用 `__HAL_AFIO_REMAP_I2C1_ENABLE()` 打开 AFIO 重映射。CubeMX 生成的代码已经包含这一句；如果没有，必须手动补上，否则 PB8/PB9 上不会有 I2C 波形。

### 生成工程

在 Project Manager 中设置工程名 `RTOS_AHT20_Lab`，工具链选择 `MDK-ARM V5.32`，应用程序结构选择 Basic，代码生成选项勾选“Generate peripheral initialization as a pair of .c/.h files”。生成后得到 `Src`、`Inc`、`Drivers`、`MDK-ARM` 等目录。随后把官方 uC/OS-III、uC/CPU、uC/LIB 源码复制到 `Middlewares` 下，并在 Keil 中建立对应的文件组。

## uC/OS-III 移植详细过程

### 移植总体思路

移植不是把内核源码“拖进工程”这么简单，而是要解决四个问题：第一，告诉内核目标 CPU 的位宽、栈增长方向和临界区指令；第二，提供 SysTick 节拍；第三，提供 PendSV 上下文切换；第四，裁剪内核配置，使其适配 64 KB Flash 和 20 KB RAM。整个过程可以概括为“复制源码、加入工程、修改配置、接入异常”。

![移植的四个步骤](figures/fig_port.png)

### 复制源码与目录组织

从官方仓库获取三个组件的源码。uC/OS-III 使用 `Ports/ARM-Cortex-M/ARMv7-M/ARM` 下的 ARMCC 汇编移植文件；uC/CPU 使用 `ARM-Cortex-M/ARMv7-M/ARM` 下的 `cpu_a.asm` 与 `cpu.h`；uC/LIB 直接使用根目录下的四个 C 文件。复制完成后的目录如下。

```text
RTOS_AHT20_Lab/
├─ Src/                          CubeMX 生成的 main.c、gpio.c、i2c.c、usart.c 等
├─ Inc/                          CubeMX 生成的头文件
├─ Drivers/                      STM32F1 HAL 与 CMSIS
├─ MDK-ARM/                      Keil 工程、启动文件、编译输出
├─ Middlewares/
│  ├─ uC-OS3/
│  │  ├─ Source/                 内核源码
│  │  ├─ Ports/ARM-Cortex-M/ARMv7-M/
│  │  │  ├─ os_cpu_c.c
│  │  │  └─ ARM/os_cpu_a.asm
│  │  └─ Cfg/                    os_cfg.h、os_cfg_app.h
│  ├─ uC-CPU/
│  │  ├─ cpu_core.c
│  │  ├─ ARM-Cortex-M/ARMv7-M/cpu_c.c
│  │  ├─ ARM-Cortex-M/ARMv7-M/ARM/cpu_a.asm
│  │  └─ Cfg/cpu_cfg.h
│  └─ uC-LIB/
│     ├─ lib_ascii.c、lib_math.c、lib_mem.c、lib_str.c
│     └─ Cfg/lib_cfg.h
└─ User/
   ├─ app.c / app.h              三个任务与 OS 启动
   ├─ app_cfg.h                  任务优先级、周期、栈大小
   ├─ led.c / led.h              LED 控制
   ├─ uart_port.c / uart_port.h  串口发送封装
   └─ aht20.c / aht20.h          AHT20 驱动
```

### Keil 文件组与头文件路径

在 Keil 中建立以下文件组，并把对应源文件加入。文件组只是逻辑分类，真正参与编译的是文件列表。

| 文件组 | 主要文件 |
|--------|----------|
| Application/MDK-ARM | `startup_stm32f103xb.s` |
| Application/User/Core | `main.c`、`gpio.c`、`i2c.c`、`usart.c`、`stm32f1xx_it.c`、`stm32f1xx_hal_msp.c`、`system_stm32f1xx.c` |
| Application/User/App | `app.c`、`led.c`、`uart_port.c`、`aht20.c` |
| uC/OS-III/Source | `os_core.c`、`os_task.c`、`os_tick.c`、`os_time.c`、`os_prio.c`、`os_cfg_app.c` 等 |
| uC/OS-III/Ports | `os_cpu_c.c`、`os_cpu_a.asm` |
| uC/CPU | `cpu_core.c`、`cpu_c.c`、`cpu_a.asm` |
| uC/LIB | `lib_ascii.c`、`lib_math.c`、`lib_mem.c`、`lib_str.c` |
| Drivers/STM32F1xx_HAL_Driver | GPIO、USART、I2C、RCC、Cortex、DMA、Flash、EXTI 等 HAL 源文件 |

头文件路径必须包含 `Src`、`Inc`、`User`、HAL 的 `Inc` 与 `Inc/Legacy`、CMSIS 的 `Include`、uC/OS-III 的 `Source`、`Ports/ARM-Cortex-M/ARMv7-M`、`Ports/ARM-Cortex-M/ARMv7-M/ARM`、`Cfg`，以及 uC/CPU、uC/LIB 的根目录和 `Cfg` 目录。缺少任意一个路径，编译器都会在 `#include <os_cfg.h>` 或 `<cpu.h>` 处报错。

### os_cfg.h 裁剪

uC/OS-III 的配置项很多。本实验只需要任务调度、延时和时钟节拍，因此关闭事件标志、内存管理、互斥量、消息队列、信号量、统计任务和定时器任务，以减少 Flash 占用和 RAM 占用。关键配置如下。

| 配置项 | 取值 | 原因 |
|--------|------|------|
| `OS_CFG_APP_HOOKS_EN` | 0 | 不使用应用钩子 |
| `OS_CFG_ARG_CHK_EN` | 1 | 保留参数检查，便于定位错误 |
| `OS_CFG_DBG_EN` | 0 | 关闭调试变量，节省 RAM |
| `OS_CFG_TICK_EN` | 1 | 必须开启系统节拍 |
| `OS_CFG_DYN_TICK_EN` | 0 | 使用固定 1 kHz 节拍 |
| `OS_CFG_PRIO_MAX` | 32 | 32 个优先级足够本实验 |
| `OS_CFG_SCHED_ROUND_ROBIN_EN` | 0 | 三个任务优先级不同，不需要同优先级轮转 |
| `OS_CFG_FLAG_EN` | 0 | 不使用事件标志 |
| `OS_CFG_MEM_EN` | 0 | 不使用动态内存 |
| `OS_CFG_MUTEX_EN` | 0 | 不使用互斥量 |
| `OS_CFG_Q_EN` | 0 | 不使用消息队列 |
| `OS_CFG_SEM_EN` | 0 | 不使用信号量 |
| `OS_CFG_STAT_TASK_EN` | 0 | 不创建统计任务 |
| `OS_CFG_TASK_PROFILE_EN` | 0 | 不记录任务运行统计 |
| `OS_CFG_TASK_REG_TBL_SIZE` | 0 | 不使用任务寄存器 |
| `OS_CFG_TMR_EN` | 0 | 不使用软件定时器 |
| `OS_CFG_TIME_DLY_HMSM_EN` | 1 | 保留时/分/秒延时接口 |

`os_cfg_app.h` 中设置 `OS_CFG_TICK_RATE_HZ` 为 1000，即 1 ms 一个节拍；空闲任务栈 128 个 `CPU_STK`；ISR 栈 128 个 `CPU_STK`；消息池 16 个。由于关闭了消息队列，消息池实际不会被使用，但保留一个较小值可以避免某些配置组合下的编译问题。

### cpu_cfg.h 配置

`cpu_cfg.h` 是移植中最容易出错的文件之一。模板中的 `CPU_CFG_NVIC_PRIO_BITS` 默认放在 `#if 0` 中，如果直接编译，`os_cpu.h` 会报“not #define'd in cpu_cfg.h”。本实验把该宏启用并设置为 4，因为 STM32F103 的 NVIC 实现了优先级高 4 位，共有 16 级可编程优先级。

| 配置项 | 取值 | 说明 |
|--------|------|------|
| `CPU_CFG_ENDIAN_TYPE` | `CPU_ENDIAN_TYPE_LITTLE` | Cortex-M3 小端 |
| `CPU_CFG_NVIC_PRIO_BITS` | 4 | STM32F103 的 4 位优先级 |
| `CPU_CFG_KA_IPL_BOUNDARY` | 4 | 优先级 4~15 的中断可以调用内核 API |
| `CPU_CFG_TS_32_EN` | `DEF_DISABLED` | 不使用时间戳 |
| `CPU_CFG_TS_64_EN` | `DEF_DISABLED` | 不使用 64 位时间戳 |
| `CPU_CFG_INT_DIS_MEAS_EN` | 未定义 | 不测量关中断时间 |
| `CPU_CFG_CACHE_MGMT_EN` | `DEF_DISABLED` | Cortex-M3 无数据缓存 |

关于 `CPU_CFG_KA_IPL_BOUNDARY`，需要和实际中断优先级一起理解。STM32F103 的优先级数值越小，优先级越高。把边界设为 4，意味着优先级数值大于等于 4 的中断属于“内核感知”中断，可以在其中调用 `OSSemPost()` 等 API；优先级 0~3 的中断不允许调用内核 API，否则会破坏内核数据结构。本实验没有使用串口中断，SysTick 的优先级由移植层设为 4，因此满足要求。

### Cortex-M3 浮点配置

STM32F103C8T6 是 Cortex-M3，没有 FPU。原版 `os_cpu.h` 在未定义 `__TARGET_FPU_SOFTVFP` 时默认把 `OS_CPU_ARM_FP_EN` 设为 1，`OSInitHook()` 会访问 FPCCR 并等待惰性压栈标志。对没有 FPU 的 M3 来说，这可能直接卡在初始化阶段。本实验在 `os_cpu.h` 中把 `OS_CPU_ARM_FP_EN` 显式改为 0，关闭浮点上下文保存。这是移植到 M3 时必须注意的一个细节。

### SysTick 的接入

uC/OS-III 需要一个 1 kHz 的系统节拍。HAL 也需要一个 1 ms 的时基来支持 `HAL_Delay()` 和 I2C 超时。最直接的做法是让两者共用同一个 SysTick 中断，而不是把 HAL 时基改到 TIM2。这样既减少了外设占用，也避免了“HAL 时基和 OS 节拍不同步”的问题。

具体做法是在 `stm32f1xx_it.c` 的 `SysTick_Handler()` 中先调用 `HAL_IncTick()`，再在 `OSRunning == OS_TRUE` 时调用移植层的 `OS_CPU_SysTickHandler()`。`OSRunning` 是内核运行标志，在 `OSStart()` 之前为 false，因此启动阶段的 SysTick 只累加 HAL 时基，不会在调度器尚未启动时调用 `OSTimeTick()`。

```c
void SysTick_Handler(void)
{
  HAL_IncTick();
  if (OSRunning == OS_TRUE) {
    OS_CPU_SysTickHandler();
  }
}
```

`OS_CPU_SysTickHandler()` 内部完成 `OSIntEnter()`、`OSTimeTick()`、`OSIntExit()` 三步。`OSIntExit()` 如果发现更高优先级任务就绪，会触发 PendSV，从而在中断返回时完成任务切换。

在 `App_Init()` 中，`OSInit()` 之后、`OSStart()` 之前调用 `OS_CPU_SysTickInitFreq(SystemCoreClock)`，把 SysTick 重装载值设为 72000-1，并把 SysTick 优先级设为 4。由于 HAL 已经在 `HAL_Init()` 中把 SysTick 配成 1 ms，这里的重配只是把优先级和重装载值再确认一次，频率仍是 1 kHz，不会破坏 HAL 时基。

### PendSV 的接入

Cortex-M3 的上下文切换在 PendSV 异常中完成。移植层的汇编文件导出 `OS_CPU_PendSVHandler`，而启动文件的向量表默认写的是弱符号 `PendSV_Handler`。一个常见的做法是在 C 文件里写 `void PendSV_Handler(void) { OS_CPU_PendSVHandler(); }`，但这样做有隐患：C 函数的序言会把进入异常时的 `LR`（EXC_RETURN）压栈并改写，移植层汇编再把 `LR` 保存到任务栈时，保存的就不是 `EXC_RETURN` 了。只有在编译器恰好把这次调用优化成尾跳转（`B` 而不是 `BL`）时才能正常工作，换优化等级或换编译器就可能出现 HardFault。

本实验采用更稳妥的做法：直接修改 `startup_stm32f103xb.s` 的向量表，把 PendSV 的表项指向移植层函数，并在文件开头用 `IMPORT` 声明外部符号。这样异常进入时 `LR` 仍然是硬件写入的 `EXC_RETURN`，汇编移植层的保存/恢复逻辑不依赖 C 编译器优化。

```asm
                IMPORT  OS_CPU_PendSVHandler
                ...
                DCD     OS_CPU_PendSVHandler       ; PendSV Handler
                DCD     SysTick_Handler            ; SysTick Handler
```

`OSStartHighRdy()` 会把 PendSV 的优先级设为最低（0xFF），这样任何中断都可以打断上下文切换，避免在中断嵌套时发生不可重入问题。`OSCtxSw()` 和 `OSIntCtxSw()` 只负责触发 PendSV，真正的寄存器保存和栈指针切换在 `OS_CPU_PendSVHandler` 中完成。

### 启动流程

`main()` 中的启动顺序如下。

1. `HAL_Init()`：初始化 Flash 接口、SysTick 和 NVIC 优先级分组。
2. `SystemClock_Config()`：配置 HSE + PLL，得到 72 MHz。
3. `MX_GPIO_Init()`、`MX_I2C1_Init()`、`MX_USART1_UART_Init()`：初始化外设。
4. `LED_Init()`：两个 LED 置为熄灭。
5. `App_Init()`：`CPU_Init()`、`OSInit()`、创建三个任务、打印启动信息、初始化 SysTick。
6. `App_Start()`：调用 `OSStart()`，启动调度器，正常情况下不返回。

```c
int main(void)
{
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_USART1_UART_Init();

  LED_Init();
  App_Init();
  App_Start();

  while (1) {
  }
}
```

### 常见移植错误与处理

| 现象 | 原因 | 处理 |
|------|------|------|
| 编译报 `CPU_CFG_NVIC_PRIO_BITS not #define'd` | 模板中该宏位于 `#if 0` 内 | 改为 `#if 1` 并设为 4 |
| 编译报 `OS_CPU_ARM_FP_EN` 相关错误 | M3 没有 FPU，模板默认开启 | 把 `OS_CPU_ARM_FP_EN` 改为 0 |
| 程序停在 `OSInitHook()` | FPCCR 访问或惰性压栈等待 | 同上，关闭 FPU 支持 |
| 下载后无任务运行 | 只创建任务但没有调用 `OSStart()` | 在 `App_Init()` 后调用 `App_Start()` |
| 串口有启动信息但 LED 不动 | SysTick 没有进入 OS 节拍处理 | 检查 `OSRunning` 判断与 `OS_CPU_SysTickHandler()` |
| 一进中断就 HardFault | 中断优先级低于 `KA_IPL_BOUNDARY` 却调用了 OS API | 把中断优先级设为 4~15，或不在其中调用 OS API |
| 任务创建返回 `OS_ERR_PRIO_INVALID` | 优先级大于等于 `OS_CFG_PRIO_MAX` | 把优先级改为 1~31 |
| 串口中文乱码 | 源文件/终端编码不一致 | 源文件用 UTF-8，串口助手也选 UTF-8 |

## 多任务程序设计

### 任务划分

三个任务的具体参数如下。任务优先级数值越小越高，因此 LED1 的实时性最好，LED2 次之，任务三最低。这样即使任务三在打印或等待 AHT20 转换，两个 LED 任务也不会被拖慢。

| 任务 | 入口函数 | 优先级 | 栈大小 | 周期 | 主要动作 |
|------|----------|--------|--------|------|----------|
| LED1 | `App_TaskLed1()` | 5 | 128 words（512 B） | 1000 ms | 翻转 PC13 |
| LED2 | `App_TaskLed2()` | 6 | 128 words（512 B） | 3000 ms | 翻转 PB0 |
| TASK3 | `App_Task3()` | 7 | 192 words（768 B） | 2000 ms | 发送 hello 或采集 AHT20 |

任务栈使用静态数组，不使用 `malloc()`。这样做的好处是链接时就能确定 RAM 占用，避免堆碎片。三个任务加上空闲任务、节拍任务和 ISR 栈，总 RAM 约 5 KB，STM32F103C8T6 的 20 KB RAM 足够。

### 任务创建

任务创建使用 `OSTaskCreate()`。以 LED1 为例，栈底指针、栈大小、栈警戒线和选项如下。`OS_OPT_TASK_STK_CLR` 会在创建时把栈清零，便于用 `OSTaskStkChk()` 查看栈使用量；`OS_OPT_TASK_STK_CHK` 允许内核检查栈。栈警戒线取栈大小的 10%，当栈剩余低于该值时，内核可以报告栈溢出。

```c
OSTaskCreate(&App_TaskLed1TCB,
             "LED1",
             App_TaskLed1,
             (void *)0,
             APP_TASK_LED1_PRIO,
             App_TaskLed1Stk,
             APP_TASK_LED_STK_SIZE / 10u,
             APP_TASK_LED_STK_SIZE,
             0u, 0u, (void *)0,
             OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR,
             &err);
```

### LED 任务

LED 任务的结构非常简单：翻转引脚，然后延时到下一个周期。这里使用 `OS_OPT_TIME_PERIODIC` 而不是普通的相对延时，是为了让任务以固定节拍运行，减少累计误差。

```c
static void App_TaskLed1(void *p_arg)
{
  OS_ERR err;
  (void)p_arg;
  while (DEF_ON) {
    LED_Toggle(LED_ID_1);
    OSTimeDly(1000u, OS_OPT_TIME_PERIODIC, &err);
    if (err != OS_ERR_NONE) {
      Error_Handler();
    }
  }
}
```

LED2 的代码完全相同，只是周期改为 3000 ms、引脚改为 PB0。由于两个任务优先级不同，LED1 每次到期都能立即抢占 LED2 或任务三，因此 1 s 节拍不会被 3 s 任务遮挡。

### 任务三的两种模式

为了同时满足任务一和任务二（3）的要求，工程用宏 `APP_TASK3_MODE` 区分任务三的行为，并在 Keil 中建立两个 Target。

| Target | 宏值 | 任务三行为 | 适用任务 |
|--------|------|------------|----------|
| `RTOS_Hello` | 1 | 每 2 s 发送 hello 字符串 | 任务一 |
| `RTOS_AHT20` | 2 | 每 2 s 采集并上报温湿度 | 任务二（3） |

`app_cfg.h` 中给出默认值 2，因此直接编译 `RTOS_AHT20` 就是最终版本；把 Target 切换到 `RTOS_Hello` 即可复现任务一的串口输出。两个 Target 共用同一套源文件，区别只在预处理器宏，便于对比，也避免维护两份代码。

hello 模式的核心代码如下。字符串使用显式 UTF-8 字节转义，避免 Keil 编辑器编码设置不同导致中文乱码。

```c
static const char APP_HELLO_STR[] =
    "hello uc/OS! "
    "\xE6\xAC\xA2\xE8\xBF\x8E\xE6\x9D\xA5\xE5\x88\xB0"
    "RTOS"
    "\xE5\xA4\x9A\xE4\xBB\xBB\xE5\x8A\xA1\xE7\x8E\xAF\xE5\xA2\x83"
    "\xEF\xBC\x81\r\n";

while (DEF_ON) {
    App_Uart_SendString(APP_HELLO_STR);
    OSTimeDly(2000u, OS_OPT_TIME_PERIODIC, &err);
}
```

### 调度时序

三个任务进入稳态后，调度关系如图 4 所示。LED1 每 1 s 翻转一次，LED2 每 3 s 翻转一次，任务三每 2 s 发送一帧。三者的最小公倍数是 6 s，因此每 6 s 三个任务会同时到期一次。由于 LED1 优先级最高，它会先执行；LED2 次之；任务三最后执行。这个顺序对 LED 的视觉效果没有影响，因为每个任务体只有几条指令。

![三个周期任务的调度时序](figures/fig_tasks.png)

## I2C 总线与 AHT20

### I2C 物理层

I2C 使用 SCL 和 SDA 两根信号线。所有设备都采用开漏输出，靠上拉电阻把总线拉高；只要有一个设备把线拉低，总线就是低电平。这种“线与”结构允许多个设备共享总线，也允许不同电压域的设备通过电平转换器连接。

| 特性 | 说明 |
|------|------|
| 信号线 | SCL（时钟）、SDA（数据） |
| 输出结构 | 开漏，需要上拉电阻 |
| 典型上拉 | 4.7 kΩ（400 kHz 时） |
| 寻址 | 7 位地址 + 1 位读写位 |
| 速率 | 标准模式 100 kHz，快速模式 400 kHz |
| 应答 | 每 8 位数据后跟 1 位 ACK/NACK |

一次完整的 I2C 传输由起始条件、地址字节、应答、数据字节、应答和停止条件组成。起始条件是 SCL 为高时 SDA 由高变低；停止条件是 SCL 为高时 SDA 由低变高。数据在 SCL 低电平期间改变，在 SCL 高电平期间保持稳定，接收方在 SCL 高电平期间采样。

![AHT20 一次测量中的 I2C 帧结构](figures/fig_i2c.png)

### 软件 I2C 与硬件 I2C

“软件 I2C”和“硬件 I2C”是两种实现方式，协议层完全相同，区别在于由谁产生时序。

| 对比项 | 软件 I2C | 硬件 I2C |
|--------|----------|----------|
| 时序产生 | CPU 用 GPIO 翻转，配合延时 | I2C 外设自动产生 |
| 引脚 | 任意 GPIO | 固定复用引脚，可重映射 |
| CPU 占用 | 高，传输期间 CPU 忙等 | 低，可配合中断/DMA |
| 速率 | 通常几十 kHz，难以做高 | 100/400 kHz 甚至更高 |
| 时序精度 | 受中断和延时影响 | 由外设时钟分频，稳定 |
| 代码复杂度 | 简单，便于理解协议 | 需要配置外设、处理状态和错误 |
| 调试 | 逻辑分析仪直接看 GPIO | 需要看外设寄存器/波形 |
| 适合场景 | 低速、引脚紧张、教学 | 批量产品、高速、多设备 |

软件 I2C 的本质是“用 CPU 模拟总线时序”。以发送一个字节为例，需要循环 8 次：把 SDA 设置为当前位，拉高 SCL，延时，拉低 SCL，再延时。接收时在 SCL 高电平期间读取 SDA。由于每次翻转都有函数调用和延时，软件 I2C 的速率通常只能做到几十 kHz，而且如果在传输过程中被中断打断，时序可能被拉长。但 I2C 是同步总线，从机不会因为时钟变慢而误判，所以软件 I2C 在低速场合仍然可靠。

硬件 I2C 由外设状态机自动完成起始、地址、数据和停止，CPU 只需要写数据寄存器、查询状态或等待中断。STM32F1 的 I2C1 还支持错误中断、DMA 和时钟拉伸。缺点是外设配置复杂，遇到总线死锁时需要手动恢复，且某些早期 STM32F1 的 I2C 外设有勘误，需要按手册规避。

本实验选择硬件 I2C，原因是：AHT20 需要 400 kHz 快速模式；STM32F103 的 I2C1 可以重映射到 PB8/PB9，接线方便；HAL 库已经封装了阻塞式收发，代码量小；而且任务三在等待转换时使用 `OSTimeDly()`，不会长时间占用 CPU。软件 I2C 则更适合理解协议或引脚受限的场合，本报告在原理部分对其进行说明，但工程实现采用硬件 I2C。

### AHT20 数据手册要点

AHT20 是一款数字温湿度传感器，内部集成电容式湿度敏感元件和带隙温度敏感元件，出厂时已经校准。它的 I2C 7 位地址是 0x38，HAL 库使用的 8 位地址是 0x70。主要参数如下。

| 参数 | 典型值/范围 | 说明 |
|------|-------------|------|
| 供电电压 | 2.2~5.5 V | 本实验用 3.3 V |
| 温度范围 | -40~85 ℃ | 精度约 ±0.3 ℃ |
| 湿度范围 | 0~100 %RH | 精度约 ±2 %RH |
| 分辨率 | 温度 0.01 ℃，湿度 0.024 %RH | 20 bit 原始值 |
| 转换时间 | 约 75 ms | 本实验等待 80 ms |
| 上电稳定 | 40 ms | 上电后先等待 |
| 通信速率 | 最高 400 kHz | 本实验 400 kHz |

一次测量分为初始化、触发、等待、读取四步。初始化命令是 `0xBE 0x08 0x00`，触发命令是 `0xAC 0x33 0x00`。触发后等待至少 75 ms，再读取 7 个字节。第 1 个字节是状态字节，bit7 为忙标志；后面 5 个字节包含 20 bit 湿度和 20 bit 温度；最后 1 个字节是 CRC。

数据拼接公式如下。湿度原始值由 `buf[1]` 的高 8 位、`buf[2]` 的全部 8 位和 `buf[3]` 的高 4 位组成；温度原始值由 `buf[3]` 的低 4 位、`buf[4]` 和 `buf[5]` 组成。

```text
raw_h = (buf[1] << 12) | (buf[2] << 4) | (buf[3] >> 4)
raw_t = ((buf[3] & 0x0F) << 16) | (buf[4] << 8) | buf[5]

RH = raw_h / 2^20 * 100 %RH
T  = raw_t / 2^20 * 200 - 50 ℃
```

![AHT20 一次测量流程](figures/fig_aht20.png)

### AHT20 驱动实现

驱动分为三个函数：`AHT20_Init()` 完成上电等待、初始化命令和状态检查；`AHT20_StartMeasurement()` 只发送触发命令；`AHT20_ReadMeasurement()` 读取 7 字节并换算。把“触发”和“读取”拆开，是为了让任务在两者之间调用 `OSTimeDly(80)`，把 80 ms 的转换时间让给其他任务。

```c
uint8_t AHT20_Init(void)
{
    uint8_t cmd[3] = {0xBE, 0x08, 0x00};
    uint8_t status = 0;
    HAL_Delay(40);
    if (HAL_I2C_Master_Transmit(&hi2c1, 0x70, cmd, 3, 100) != HAL_OK) {
        return 0;
    }
    HAL_Delay(10);
    if (HAL_I2C_Master_Receive(&hi2c1, 0x70, &status, 1, 100) != HAL_OK) {
        return 0;
    }
    if ((status & 0x80) != 0) {
        return 0;
    }
    return ((status & 0x18) == 0x18) ? 1 : 0;
}
```

状态字节的 bit7 是忙标志，bit4 是校准完成，bit3 是校准使能。只有 bit7 为 0 且 bit4/bit3 都为 1，才认为初始化成功。如果传感器没有接好，`AHT20_Init()` 会返回 0，任务三会打印错误信息并在下一个周期重试，而不是死等。

读取函数先检查忙标志，再拼接原始值。温度可能为负，格式化时单独处理符号。为了避免在 Keil 中引入浮点 `printf` 支持，程序把温度乘以 100 后转成整数，再用 `%ld.%02ld` 输出两位小数。

```c
raw_h = ((uint32_t)buf[1] << 12) |
        ((uint32_t)buf[2] << 4)  |
        ((uint32_t)buf[3] >> 4);
raw_t = (((uint32_t)buf[3] & 0x0Fu) << 16) |
        ((uint32_t)buf[4] << 8) |
         (uint32_t)buf[5];

*humidity    = (float)raw_h * 100.0f / 1048576.0f;
*temperature = (float)raw_t * 200.0f / 1048576.0f - 50.0f;
```

### 任务三改造为 AHT20 采集

AHT20 模式下，任务三先初始化传感器，然后进入 2 s 周期。每个周期内：触发测量，`OSTimeDly(80)` 让出 CPU，读取并换算，串口输出，最后 `OSTimeDly(2000)` 等待下一个周期。80 ms 的转换时间不会阻塞 LED 任务，因为 LED 任务的优先级更高，SysTick 到期后可以立即抢占。

```c
static void App_Aht20Report(void)
{
    static uint8_t sensor_ready = 0;
    float t, h;
    int32_t t100, h100;
    char sign;

    if (!sensor_ready) {
        sensor_ready = AHT20_Init();
        if (!sensor_ready) {
            App_Uart_SendString("[TASK3] AHT20 init failed\r\n");
            return;
        }
    }
    if (!AHT20_StartMeasurement()) {
        sensor_ready = 0;
        return;
    }
    OSTimeDly(80, OS_OPT_TIME_DLY, &err);
    if (!AHT20_ReadMeasurement(&t, &h)) {
        sensor_ready = 0;
        return;
    }
    /* 定点格式化后通过 USART1 输出 */
}
```

这里的 80 ms 延时使用 `OSTimeDly()`，而不是 `HAL_Delay()`。`HAL_Delay()` 是忙等，虽然中断仍然响应，但当前任务会一直占用 CPU，低优先级任务无法运行；`OSTimeDly()` 会把当前任务从就绪表移除，调度器立刻切换到其他任务。这是 RTOS 编程与裸机编程最重要的区别之一。

## 编译、下载与串口观察

本报告完成的验证包括：CubeMX 工程配置检查、Keil 两个 Target 的完整重编译（均为 0 Error、0 Warning）、链接尺寸检查和源码静态检查。由于当前整理环境未连接实验板，LED 节拍以理论时序给出，串口图是按程序实际格式生成的示意而非实机截图；上板后按 8.2、8.3 和附录 A 的步骤操作，即可得到真实波形与截图。报告中对“预期现象”和“实测数据”做了区分，避免把格式示意误当成测量结果。

### 编译两个 Target

打开 `MDK-ARM/RTOS_AHT20_Lab.uvprojx`，在工具栏的 Target 下拉框中选择 `RTOS_AHT20`，按 F7 编译。编译成功后会在 `MDK-ARM/RTOS_AHT20/` 下生成 `.axf`、`.hex` 和 `.map` 文件。切换到 `RTOS_Hello` 再编译一次，即可得到任务一的程序。

| Target | Code | RO-data | RW-data | ZI-data | 结果 |
|--------|------|---------|---------|---------|------|
| RTOS_AHT20 | 20046 B | 894 B | 56 B | 5104 B | 0 Error, 0 Warning |
| RTOS_Hello | 15832 B | 944 B | 56 B | 5104 B | 0 Error, 0 Warning |

Flash 占用约为 Code + RO-data + RW-data，AHT20 版本约 21 KB，Hello 版本约 16.8 KB，均小于 64 KB。RAM 占用约为 RW-data + ZI-data，即 5160 B，约 5.04 KB，小于 20 KB。ZI-data 中已经包含三个任务栈、空闲任务栈、节拍任务栈和 ISR 栈。

![Keil 编译结果](figures/fig_build.png)

### 下载与运行

用 ST-Link V2 连接板子的 SWD 接口，注意 3.3 V、GND、SWDIO、SWCLK 四根线不要接错。Keil 中选择 `Options for Target -> Debug -> ST-Link Debugger`，在 `Settings` 中确认能识别到芯片。点击 Download 下载，按复位键运行。BOOT0 保持 0，从 Flash 启动。

### 串口助手设置

打开 XCOM、SSCOM 或任意串口助手，选择 USB-TTL 对应的 COM 口，参数设置为 115200、8 数据位、1 停止位、无校验、无流控。由于程序发送的是 UTF-8 编码的中文字节，串口助手必须选择 UTF-8 编码；如果显示乱码，先把终端编码改为 UTF-8，再检查源文件是否被保存成了 GBK。

AHT20 版本的输出格式如下。每 2 s 一行，温度保留两位小数，湿度保留两位小数。实际数值会随环境变化，下图是格式示意，实机测试时应用 XCOM 保存真实截图。

```text
[BOOT] uC/OS-III V3.08.02 on STM32F103C8T6
[BOOT] LED1=PC13/1 s, LED2=PB0/3 s
[BOOT] TASK3 mode: AHT20, period = 2 s
========================================
[TASK3] AHT20 init OK
[TASK3] AHT20: T= 25.36 C, RH= 48.72 %RH
[TASK3] AHT20: T= 25.38 C, RH= 48.69 %RH
```

Hello 版本的输出格式如下。每 2 s 一行，字符串内容与题目要求一致。

```text
[BOOT] TASK3 mode: hello, period = 2 s
hello uc/OS! 欢迎来到RTOS多任务环境！
hello uc/OS! 欢迎来到RTOS多任务环境！
```

![串口输出格式示意](figures/fig_serial.png)

## 实验结果与分析

### LED 节拍

上板运行时，预期 LED1 以 1 s 任务周期翻转，LED2 以 3 s 任务周期翻转。由于任务启动时先翻转一次，LED1 在 1 s 后熄灭、2 s 后点亮，LED2 在 3 s 后熄灭、6 s 后点亮。用示波器或逻辑分析仪同时抓取 PC13 和 PB0，应能看到两路方波的周期分别为 2 s 和 6 s，占空比 50%。如果两路方波都稳定，说明两个任务都在按各自的延时独立运行，没有因为任务三的串口发送或 AHT20 转换而丢拍。

| 观察点 | 理论值 | 测量方法 |
|--------|--------|----------|
| LED1 任务唤醒间隔 | 1000 ms | 逻辑分析仪测 PC13 相邻下降沿 |
| LED1 完整亮灭周期 | 2000 ms | 示波器测 PC13 一个完整方波 |
| LED2 任务唤醒间隔 | 3000 ms | 逻辑分析仪测 PB0 相邻下降沿 |
| LED2 完整亮灭周期 | 6000 ms | 示波器测 PB0 一个完整方波 |
| 任务三发送间隔 | 2000 ms | 串口助手时间戳或逻辑分析仪测 PA9 |

### AHT20 数据

上板验证时，AHT20 初始化成功后，串口应每 2 s 输出一行温湿度。用手捂住传感器，预期湿度逐渐上升、温度向体温靠近；松开后数值慢慢恢复。如果数据随环境变化，说明驱动读取的是真实转换结果，而不是固定值。若读数长时间为 0 或初始化失败，应优先检查 PB8/PB9 是否接反、模块是否 3.3 V 供电、上拉电阻是否足够。

### 实时性分析

任务三的串口发送采用轮询，一帧约 45 字节，115200 bit/s 下约 3.9 ms。AHT20 转换等待 80 ms 使用 `OSTimeDly()`，不占用 CPU。LED 任务优先级更高，因此任务三的这两段耗时不会导致 LED 明显抖动。最坏情况下，任务三在临界区内关中断的时间只有几十个时钟周期，远小于 1 ms 节拍，不会丢失 SysTick。

从内存角度看，AHT20 版本比 Hello 版本多约 4.2 KB Flash，主要用于 I2C HAL 驱动、浮点换算和格式化代码；RAM 两者相同，因为任务栈大小没有变化。对于 64 KB Flash、20 KB RAM 的 STM32F103C8T6，余量充足。

### 误差来源

温湿度读数误差主要来自三个方面。第一，AHT20 自身精度约为 ±0.3 ℃、±2 %RH，且需要避免阳光直射和气流。第二，传感器靠近 MCU 和稳压器，板级发热会使温度略高于环境温度。第三，I2C 线较长或上拉不足时，波形上升沿变缓，可能导致偶发 NACK。工程中已经把 I2C 速率设为 400 kHz，并在初始化失败时重试，实际使用时建议缩短杜邦线并保证共地。

## 遇到的问题与解决

### 编译时报 CPU_CFG_NVIC_PRIO_BITS 未定义

第一次编译时，`os_cpu.h` 报 `CPU_CFG_NVIC_PRIO_BITS not #define'd in cpu_cfg.h`，同时 `cpu_c.c`、`lib_math.c`、`lib_mem.c` 也报该标识符未定义。检查发现 `cpu_cfg.h` 模板把该宏放在 `#if 0` 中，是示例配置，默认不生效。把 `#if 0` 改为 `#if 1` 后重新编译，51 个错误全部消失。

### Cortex-M3 的 FPU 配置

原版 `os_cpu.h` 在没有定义 `__TARGET_FPU_SOFTVFP` 时默认开启 `OS_CPU_ARM_FP_EN`。STM32F103 没有 FPU，如果直接运行，`OSInitHook()` 可能访问不存在的 FPCCR 并卡死。把该宏改为 0 后，内核不再保存浮点上下文，启动正常。这个问题在编译阶段不一定报错，属于“编译通过但运行卡死”的典型移植坑。

### SysTick 被 HAL 和 OS 重复使用

如果直接把 `SysTick_Handler()` 改成 `OS_CPU_SysTickHandler()`，HAL 的 `HAL_IncTick()` 就不会执行，`HAL_Delay()` 和 I2C 超时会失效。本实验保留 `HAL_IncTick()`，再调用 OS 的节拍处理，并用 `OSRunning` 判断避免在 `OSStart()` 之前进入内核。这样一套 1 kHz 节拍同时服务 HAL 和 uC/OS-III，不需要把 HAL 时基改到 TIM2。

### I2C1 默认引脚不是 PB8/PB9

STM32F103 的 I2C1 默认在 PB6/PB7，而开发板的 OLED/AHT20 接口在 PB8/PB9。如果只配置 GPIO 而不打开 AFIO 重映射，总线上不会有波形。CubeMX 生成的 `HAL_I2C_MspInit()` 中已经包含 `__HAL_AFIO_REMAP_I2C1_ENABLE()`，移植时要确认这一句没有被删掉。

### 串口中文乱码

代码中的 hello 字符串使用 UTF-8 字节转义，源文件本身也保存为 UTF-8。如果串口助手选择 GBK，中文会显示为乱码；把终端编码改为 UTF-8 即可。另一个常见原因是 Keil 编辑器把源文件保存成了 GBK，导致字符串字节与终端不一致；建议在 VSCode 中统一使用 UTF-8，并在 Keil 中关闭“自动检测编码”。

### AHT20 初始化失败

AHT20 初始化失败通常有三个原因：供电不是 3.3 V、SDA/SCL 接反、上拉电阻不足。模块自带 4.7 kΩ 上拉时可以直接并联；如果使用长杜邦线，建议缩短到 20 cm 以内。程序中初始化失败不会死机，而是每 2 s 重试并打印错误，方便定位。

## 总结

本实验完成了从裸机到 RTOS 的完整迁移。通过 STM32CubeMX 建立 HAL 工程，移植 uC/OS-III V3.08.02，配置 1 kHz SysTick，接入 PendSV 上下文切换，最终在 STM32F103C8T6 上稳定运行三个周期任务。LED1 和 LED2 分别以 1 s、3 s 的任务周期翻转，任务三以 2 s 周期发送 hello 字符串；在此基础上，任务三被改造成 AHT20 采集任务，通过硬件 I2C 每 2 s 读取一次温湿度并从 USART1 输出。

移植过程中最有价值的经验有三点。第一，配置文件不是“默认就能用”的，`CPU_CFG_NVIC_PRIO_BITS`、`OS_CPU_ARM_FP_EN` 这类宏必须结合目标 CPU 逐项确认。第二，SysTick 和 PendSV 是 Cortex-M 移植的核心，必须把 HAL 时基、OS 节拍和中断优先级作为一个整体考虑。第三，RTOS 的价值不仅在于“多任务”，更在于把等待时间变成可调度的时间；AHT20 的 80 ms 转换等待用 `OSTimeDly()` 实现后，LED 任务仍能按时运行，这是裸机 `HAL_Delay()` 做不到的。

后续可以继续扩展：用信号量保护串口、用消息队列把传感器数据发送给显示任务、用软件定时器做周期性采样、用 DMA 发送串口数据，或者把 AHT20 与 OLED 挂在同一条 I2C 总线上，做一个带显示的温湿度终端。这些扩展都可以在现有工程上逐步加入，而不需要重写移植层。

## 参考资料

1. STM32F103C8T6 移植 uC/OS-III 基于 HAL 库超完整详细过程：https://blog.csdn.net/weixin_43116606/article/details/105532222
2. uC/OS-III 移植与任务创建示例：https://blog.csdn.net/junseven164/article/details/121534916
3. uC/OS-III 移植踩坑总结：https://blog.csdn.net/qq_45659777/article/details/121570886
4. STM32 通过 I2C 接口实现 AHT20 温湿度采集：https://blog.csdn.net/qq_43279579/article/details/111597278
5. I2C 总线通信协议及 AHT20 采集实操：https://blog.csdn.net/qq_46467126/article/details/121436790
6. STM32F103 基于 I2C 协议的 AHT20 数据采集（HAL 库）：https://blog.csdn.net/qq_47281915/article/details/121438731
7. Weston Embedded uC/OS-III 官方源码：https://github.com/weston-embedded/uC-OS3
8. Weston Embedded uC/CPU 官方源码：https://github.com/weston-embedded/uC-CPU
9. Weston Embedded uC/LIB 官方源码：https://github.com/weston-embedded/uC-LIB
10. AHT20 产品手册与官方 Demo（AHT20-21 DEMO V1_3、AHT20 产品手册 a2.pdf）
11. 野火《STM32F103 开发指南》第 23 章“I2C--读写 EEPROM”原理部分
12. STM32F103x8/xB 数据手册与参考手册 RM0008

## 附录 A 工程编译与下载步骤

1. 用 STM32CubeMX 打开 `RTOS_AHT20_Lab.ioc`，确认芯片为 STM32F103C8T6、HSE 8 MHz、PLL×9、USART1 115200、I2C1 400 kHz、PC13/PB0 为输出。
2. 用 Keil 打开 `MDK-ARM/RTOS_AHT20_Lab.uvprojx`。
3. 在 Target 下拉框选择 `RTOS_AHT20`（AHT20 采集）或 `RTOS_Hello`（hello 输出）。
4. 按 F7 编译，确认 Build Output 为 0 Error(s)、0 Warning(s)。
5. 用 ST-Link 连接 SWD，点击 Download 下载，按复位运行。
6. 用 USB-TTL 连接 PA9/PA10，打开串口助手，选择 115200-8-N-1、UTF-8。
7. 观察 LED1 每 1 s 翻转、LED2 每 3 s 翻转，串口每 2 s 输出一帧。
8. 若使用 AHT20，先确认模块 3.3 V 供电、PB8/PB9 接线、上拉电阻，再上电。

## 附录 B 关键文件说明

| 文件 | 说明 |
|------|------|
| `RTOS_AHT20_Lab.ioc` | CubeMX 配置文件，记录时钟、引脚和外设参数 |
| `Src/main.c` | HAL 初始化、调用 `App_Init()` 与 `App_Start()` |
| `Src/stm32f1xx_it.c` | SysTick 与 PendSV 的移植接入点 |
| `Src/i2c.c` | I2C1 初始化与 PB8/PB9 重映射 |
| `User/app.c` | 三个任务、任务创建、AHT20 上报 |
| `User/app_cfg.h` | 任务优先级、周期、栈大小、任务三模式 |
| `User/aht20.c` | AHT20 初始化、触发、读取与换算 |
| `User/uart_port.c` | USART1 轮询发送与格式化输出 |
| `Middlewares/uC-OS3/Cfg/os_cfg.h` | 内核功能裁剪 |
| `Middlewares/uC-OS3/Cfg/os_cfg_app.h` | 节拍频率、任务栈、ISR 栈 |
| `Middlewares/uC-CPU/Cfg/cpu_cfg.h` | NVIC 位数、大小端、内核感知边界 |
| `MDK-ARM/RTOS_AHT20_Lab.uvprojx` | 两个 Target 的 Keil 工程 |
