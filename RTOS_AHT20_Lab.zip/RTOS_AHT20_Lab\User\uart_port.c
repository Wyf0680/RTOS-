/**
  ******************************************************************************
  * @file    uart_port.c
  * @brief   USART1 轮询发送实现
  *
  *  说明：
  *    1. 发送距离很短（每 2 s 一帧、约 50 字节），115200 bit/s 下耗时约 4 ms，
  *       因此在任务中直接使用 HAL_UART_Transmit() 轮询发送即可，不引入串口
  *       中断和环形缓冲区，降低移植难度。
  *    2. 若后续需要高吞吐量，可改为 DMA + 信号量，本实验不展开。
  ******************************************************************************
  */
#include "uart_port.h"
#include "usart.h"
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

void App_Uart_SendBytes(const uint8_t *buf, uint16_t len)
{
    if ((buf == NULL) || (len == 0u)) {
        return;
    }
    (void)HAL_UART_Transmit(&huart1, (uint8_t *)buf, len, 1000u);
}

void App_Uart_SendString(const char *str)
{
    if (str == NULL) {
        return;
    }
    App_Uart_SendBytes((const uint8_t *)str, (uint16_t)strlen(str));
}

void App_Uart_Printf(const char *fmt, ...)
{
    char buf[128];
    va_list ap;
    int n;

    if (fmt == NULL) {
        return;
    }

    va_start(ap, fmt);
    n = vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);

    if (n <= 0) {
        return;
    }
    if (n >= (int)sizeof(buf)) {
        n = (int)sizeof(buf) - 1;
    }
    App_Uart_SendBytes((const uint8_t *)buf, (uint16_t)n);
}
