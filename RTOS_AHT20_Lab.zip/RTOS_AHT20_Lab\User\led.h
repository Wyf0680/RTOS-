/**
  ******************************************************************************
  * @file    led.h
  * @brief   LED 控制接口
  *
  *  开发板：STM32F103C8T6 最小系统板（Blue Pill）
  *    LED1：PC13，板载 LED，低电平点亮
  *    LED2：PB0，外接 LED，低电平点亮（PB0 -> 330 Ω -> LED -> 3.3 V）
  ******************************************************************************
  */
#ifndef __LED_H
#define __LED_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define LED_ID_1    1u
#define LED_ID_2    2u

void LED_Init(void);
void LED_On(uint8_t id);
void LED_Off(uint8_t id);
void LED_Toggle(uint8_t id);

#ifdef __cplusplus
}
#endif

#endif /* __LED_H */
