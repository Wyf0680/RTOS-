/**
  ******************************************************************************
  * @file    aht20.h
  * @brief   AHT20 温湿度传感器驱动（I2C，7 位地址 0x38）
  *
  *  与“阻塞式”驱动不同，本驱动把一次测量拆成两步：
  *      AHT20_StartMeasurement()  -> 触发转换
  *      OSTimeDly(80 ms)           -> 让出 CPU，低优先级任务可运行
  *      AHT20_ReadMeasurement()   -> 读取 7 字节并换算
  *  这样 80 ms 的转换等待不会阻塞 RTOS 调度。
  ******************************************************************************
  */
#ifndef __AHT20_H
#define __AHT20_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define AHT20_I2C_ADDR      (0x38u << 1)

uint8_t AHT20_Init(void);
uint8_t AHT20_StartMeasurement(void);
uint8_t AHT20_ReadMeasurement(float *temperature, float *humidity);

#ifdef __cplusplus
}
#endif

#endif /* __AHT20_H */
