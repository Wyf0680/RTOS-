/**
  ******************************************************************************
  * @file    app.c
  * @brief   三任务应用：LED1(1 s)、LED2(3 s)、任务三(2 s)
  *
  *  任务划分：
  *    Task LED1  priority 5  period 1000 ms  PC13 翻转
  *    Task LED2  priority 6  period 3000 ms  PB0  翻转
  *    Task UART  priority 7  period 2000 ms  hello 或 AHT20 温湿度
  *
  *  调度策略：
  *    三个任务都是周期任务，执行体很短，执行完后调用 OSTimeDly() 主动让出 CPU；
  *    调度器在 SysTick 中断中递减延时计数，到期后按优先级恢复任务。
  *    LED 任务优先级高于串口任务，因此串口打印/传感器转换不会影响 LED 的节拍。
  ******************************************************************************
  */
#include "app.h"
#include "app_cfg.h"
#include "os.h"
#include "main.h"
#include "led.h"
#include "uart_port.h"
#include "aht20.h"

#include <stdint.h>

/* ------------------------------ 任务控制块与栈 ------------------------------ */
static OS_TCB  App_TaskLed1TCB;
static OS_TCB  App_TaskLed2TCB;
static OS_TCB  App_Task3TCB;

static CPU_STK App_TaskLed1Stk[APP_TASK_LED_STK_SIZE];
static CPU_STK App_TaskLed2Stk[APP_TASK_LED_STK_SIZE];
static CPU_STK App_Task3Stk[APP_TASK3_STK_SIZE];

/* 任务三 hello 模式字符串：显式 UTF-8 字节，避免编译器源文件编码差异 --------*/
static const char APP_HELLO_STR[] =
    "hello uc/OS! "
    "\xE6\xAC\xA2\xE8\xBF\x8E\xE6\x9D\xA5\xE5\x88\xB0"
    "RTOS"
    "\xE5\xA4\x9A\xE4\xBB\xBB\xE5\x8A\xA1\xE7\x8E\xAF\xE5\xA2\x83"
    "\xEF\xBC\x81\r\n";

/* ------------------------------- 函数声明 ---------------------------------- */
static void App_TaskLed1(void *p_arg);
static void App_TaskLed2(void *p_arg);
static void App_Task3(void *p_arg);
static void App_CreateTask(OS_TCB *p_tcb, const char *name, OS_TASK_PTR task,
                           OS_PRIO prio, CPU_STK *p_stk, CPU_STK_SIZE stk_size);
#if (APP_TASK3_MODE == APP_TASK3_MODE_AHT20)
static void App_Aht20Report(void);
#endif

/* ------------------------------- 任务实现 ---------------------------------- */
static void App_TaskLed1(void *p_arg)
{
    OS_ERR err;

    (void)p_arg;

    while (DEF_ON) {
        LED_Toggle(LED_ID_1);           /* 每 1 s 翻转一次：亮 1 s、灭 1 s */
        OSTimeDly(APP_TASK_LED1_PERIOD_MS, OS_OPT_TIME_PERIODIC, &err);
        if (err != OS_ERR_NONE) {
            Error_Handler();
        }
    }
}

static void App_TaskLed2(void *p_arg)
{
    OS_ERR err;

    (void)p_arg;

    while (DEF_ON) {
        LED_Toggle(LED_ID_2);           /* 每 3 s 翻转一次：亮 3 s、灭 3 s */
        OSTimeDly(APP_TASK_LED2_PERIOD_MS, OS_OPT_TIME_PERIODIC, &err);
        if (err != OS_ERR_NONE) {
            Error_Handler();
        }
    }
}

static void App_Task3(void *p_arg)
{
    OS_ERR err;

    (void)p_arg;

#if (APP_TASK3_MODE == APP_TASK3_MODE_HELLO)
    /* 任务一要求：每 2 s 通过 USART1 发送 hello 字符串 */
    while (DEF_ON) {
        App_Uart_SendString(APP_HELLO_STR);
        OSTimeDly(APP_TASK3_PERIOD_MS, OS_OPT_TIME_PERIODIC, &err);
        if (err != OS_ERR_NONE) {
            Error_Handler();
        }
    }
#elif (APP_TASK3_MODE == APP_TASK3_MODE_AHT20)
    /* 任务二（3）要求：每 2 s 采集一次 AHT20 并通过 USART1 上报 */
    App_Uart_SendString("[TASK3] AHT20 monitor started, period = 2 s\r\n");
    while (DEF_ON) {
        App_Aht20Report();
        OSTimeDly(APP_TASK3_PERIOD_MS, OS_OPT_TIME_PERIODIC, &err);
        if (err != OS_ERR_NONE) {
            Error_Handler();
        }
    }
#else
#error "APP_TASK3_MODE must be APP_TASK3_MODE_HELLO or APP_TASK3_MODE_AHT20"
#endif
}

#if (APP_TASK3_MODE == APP_TASK3_MODE_AHT20)
static void App_Aht20Report(void)
{
    static uint8_t sensor_ready = 0u;
    OS_ERR err;
    float temperature;
    float humidity;
    int32_t t100;
    int32_t h100;
    char sign;

    if (sensor_ready == 0u) {
        sensor_ready = AHT20_Init();
        if (sensor_ready == 0u) {
            App_Uart_SendString("[TASK3] AHT20 init failed, check PB8/PB9 wiring\r\n");
            return;
        }
        App_Uart_SendString("[TASK3] AHT20 init OK\r\n");
    }

    if (AHT20_StartMeasurement() == 0u) {
        App_Uart_SendString("[TASK3] AHT20 trigger failed\r\n");
        sensor_ready = 0u;
        return;
    }

    /* 转换期间主动阻塞当前任务 80 ms；LED 任务优先级更高，仍可按时运行 */
    OSTimeDly(APP_AHT20_CONV_MS, OS_OPT_TIME_DLY, &err);
    if (err != OS_ERR_NONE) {
        Error_Handler();
    }

    if (AHT20_ReadMeasurement(&temperature, &humidity) == 0u) {
        App_Uart_SendString("[TASK3] AHT20 read failed\r\n");
        sensor_ready = 0u;
        return;
    }

    /* 定点格式化，避免在 Keil 工程中引入浮点 printf 支持 */
    if (temperature >= 0.0f) {
        t100 = (int32_t)(temperature * 100.0f + 0.5f);
        sign = ' ';
    } else {
        t100 = (int32_t)(temperature * 100.0f - 0.5f);
        sign = '-';
    }
    if (t100 < 0) {
        t100 = -t100;
    }

    h100 = (int32_t)(humidity * 100.0f + 0.5f);

    App_Uart_Printf("[TASK3] AHT20: T=%c%ld.%02ld C, RH=%ld.%02ld %%RH\r\n",
                    sign,
                    (long)(t100 / 100),
                    (long)(t100 % 100),
                    (long)(h100 / 100),
                    (long)(h100 % 100));
}
#endif

/* ------------------------------- 初始化 ------------------------------------ */
static void App_CreateTask(OS_TCB *p_tcb, const char *name, OS_TASK_PTR task,
                           OS_PRIO prio, CPU_STK *p_stk, CPU_STK_SIZE stk_size)
{
    OS_ERR err;

    OSTaskCreate(p_tcb,
                 (CPU_CHAR *)name,
                 task,
                 (void *)0,
                 prio,
                 p_stk,
                 stk_size / APP_TASK_STK_LIMIT_PCT,
                 stk_size,
                 0u,
                 0u,
                 (void *)0,
                 (OS_OPT)(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
                 &err);
    if (err != OS_ERR_NONE) {
        App_Uart_Printf("[BOOT] OSTaskCreate(%s) failed, err=%d\r\n", name, (int)err);
        Error_Handler();
    }
}

void App_Init(void)
{
    OS_ERR err;

    CPU_Init();                         /* uC/CPU 初始化，必须在 OSInit() 之前 */
    OSInit(&err);
    if (err != OS_ERR_NONE) {
        Error_Handler();
    }

    App_CreateTask(&App_TaskLed1TCB, "LED1", App_TaskLed1,
                   APP_TASK_LED1_PRIO, App_TaskLed1Stk, APP_TASK_LED_STK_SIZE);
    App_CreateTask(&App_TaskLed2TCB, "LED2", App_TaskLed2,
                   APP_TASK_LED2_PRIO, App_TaskLed2Stk, APP_TASK_LED_STK_SIZE);
    App_CreateTask(&App_Task3TCB, "TASK3", App_Task3,
                   APP_TASK3_PRIO, App_Task3Stk, APP_TASK3_STK_SIZE);

    App_Uart_SendString("\r\n========================================\r\n");
    App_Uart_Printf("[BOOT] uC/OS-III V%u.%02u.%02u on STM32F103C8T6\r\n",
                    (unsigned)(OS_VERSION / 10000u),
                    (unsigned)((OS_VERSION / 100u) % 100u),
                    (unsigned)(OS_VERSION % 100u));
    App_Uart_SendString("[BOOT] LED1=PC13/1 s, LED2=PB0/3 s\r\n");
#if (APP_TASK3_MODE == APP_TASK3_MODE_HELLO)
    App_Uart_SendString("[BOOT] TASK3 mode: hello, period = 2 s\r\n");
#else
    App_Uart_SendString("[BOOT] TASK3 mode: AHT20, period = 2 s\r\n");
#endif
    App_Uart_SendString("========================================\r\n");

    /* 用 1 kHz SysTick 同时作为 HAL 时基和 uC/OS-III 系统节拍。
       必须在 OSInit() 之后调用，因为 OSCfg_TickRate_Hz 在 OSInit() 中初始化。 */
    CPU_SR_ALLOC();
    CPU_CRITICAL_ENTER();
    OS_CPU_SysTickInitFreq(SystemCoreClock);
    CPU_CRITICAL_EXIT();
}

void App_Start(void)
{
    OS_ERR err;

    OSStart(&err);

    /* OSStart() 正常情况下不会返回；返回说明没有就绪任务 */
    (void)err;
    Error_Handler();
}
