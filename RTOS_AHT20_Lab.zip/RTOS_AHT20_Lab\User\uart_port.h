/**
  ******************************************************************************
  * @file    uart_port.h
  * @brief   USART1 串口输出封装（PA9/PA10，115200-8-N-1）
  ******************************************************************************
  */
#ifndef __UART_PORT_H
#define __UART_PORT_H

#include <stdint.h>
#include "stm32f1xx_hal.h"

#ifdef __cplusplus
extern "C" {
#endif

void App_Uart_SendString(const char *str);
void App_Uart_SendBytes(const uint8_t *buf, uint16_t len);
void App_Uart_Printf(const char *fmt, ...);

#ifdef __cplusplus
}
#endif

#endif /* __UART_PORT_H */
