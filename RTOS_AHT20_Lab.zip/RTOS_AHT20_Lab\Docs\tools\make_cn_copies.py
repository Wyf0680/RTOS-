# -*- coding: utf-8 -*-
"""Create Chinese-named copies for submission while keeping ASCII names for tooling."""
import os
import shutil

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

pairs = [
    ("Lab_Report.md", "实验报告.md"),
    ("Lab_Report.pdf", "实验报告.pdf"),
]

for src_name, dst_name in pairs:
    src = os.path.join(ROOT, src_name)
    dst = os.path.join(ROOT, dst_name)
    if os.path.exists(src):
        shutil.copyfile(src, dst)
        print("copied", src_name, "->", dst_name)
    else:
        print("missing", src_name)
